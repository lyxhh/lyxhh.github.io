---
title: Python Requests Library
date: 2017-10-16 21:43:46
categories:
	- Python
tags:
	- Requests Library 
---


Python requests <!-- more -->
# Requests: 让 HTTP 服务人类

[开源地址](https://github.com/kennethreitz/requests)
[中文文档](http://docs.python-requests.org/zh_CN/latest/index.html)

```
Requests 支持 Python 2.6—2.7以及3.3—3.7，而且能在 PyPy 下完美运行。
```

## 安装方式
```
pip3 install requests
```

## 发送请求
```
import requests
# 发送get请求
response = requests.get('http://www.lxhsec.com')
# 发送post请求
response = requests.post('https://github.com/timeline.json')
# 发送put请求
response = requests.put('https://github.com/timeline.json')
# 发送delete请求
response = requests.delete('https://github.com/timeline.json')
# 发送head请求
response = requests.head('https://github.com/timeline.json')
# 发送options请求
response = requests.options('https://github.com/timeline.json')
都很不错吧，但这也仅是 Requests 的冰山一角呢。
```

## GET request
```
header = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",}
response = requests.get("http://www.lxhsec.com/", headers=header)
print(response.text) # 返回的是Unicode格式的数据，即我们浏览器右键查看源代码所看到的。
print(response.status_code) # 获取url状态码
print(response.url) # 获取当前请求的url
print(response.content) # 返回字节流格式的数据,
print(response.encoding) # python默认utf-8 
print(response.headers) # 我们可以查看以一个 Python 字典形式展示的服务器响应头：
-- 传递url参数
kw={'wd':'blog'} # wd=blog 字典类型自动转换为url编码。中文也是没问题滴
response = requests.get("https://www.baidu.com/s?", headers=header, params=kw)
print(response.url) # 获取当前请求的url
# https://www.baidu.com/s?wd=blog
```

## POST request
```
要实现这个，只需简单地传递一个字典给 data 参数。
你的数据字典在发出请求时会自动编码为表单形式
import urllib
import requests
url = "http://fanyi.youdao.com/translate?smartresult=dict&smartresult=rule&smartresult=ugc&sessionFrom=null"
headers = {
"Accept": "application/json, text/javascript, */*; q=0.01",
"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
           }
r = input("请输入要翻译的英文：")
formdata = {
    "i": r,
    "from": "AUTO",
    "to": "AUTO",
    "smartresult": "dict",
    "client": "fanyideskweb",
    "salt": "1507099300084",
    "sign": "a0bf3bb0280c68d8cc20c2b1864f72f5",
    "doctype": "json",
    "version": "2.1",
    "keyfrom": "fanyi.web",
    "action": "FY_BY_CLICKBUTTION",
    "typoResult": "true"
}
data = urllib.parse.urlencode(formdata)
r = requests.post(url,data=data,headers=headers)
print(r.text)
代码最好在linux上跑 windows容易出问题。
```

![post1](http://owrmua5nw.bkt.clouddn.com/post.png)
![result](http://owrmua5nw.bkt.clouddn.com/result.png)

## [](#proxies "proxies")proxies

代理网站：

*   [西刺免费代理IP](http://www.xicidaili.com/)
*   [快代理免费代理](http://www.kuaidaili.com/free/inha/)
*   [Proxy360代理](http://www.proxy360.cn/default.aspx)
*   [全网代理IP](http://www.goubanjia.com/free/index.shtml)

```
可以通过为任意请求方法提供 proxies 参数来设置代理
import requests
# 根据协议类型，选择不同的代理
proxies = {
  "http": "118.119.168.172:9999",
  "https": "119.90.63.3:3128"
}
response = requests.get("http://www.baidu.com", proxies = proxies)
print (response.text)
```

### 私密代理
```
proxies = {
    "http": "http://user:pass@10.10.1.10:3128/",
}
注意，代理 URL 必须包含连接方式。
```

## web客户端验证
```
import requests
auth=('user', 'pass')
response = requests.get('http://192.168.199.107:port', auth = auth)
print (response.text)
```

## 会话对象

*   会话对象让你能够跨请求保持某些参数。它也会在同一个 Session 实例发出的所有请求之间保持 cookie
*   在 requests 里，session对象是一个非常常用的对象，这个对象代表一次用户会话：从客户端浏览器连接服务器开始，到客户端浏览器与服务器断开。

### 实现人人网登录
```
# coding:utf-8
import requests
# 1. 创建session对象，可以保存Cookie值
session = requests.session()
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36"}
# 2. POST登陆表单
data = {"email":"values", "password":"value"}  
# 3. 发送附带用户名和密码的请求，并获取登录后的Cookie值，保存在session里。
由于是老接口并不需要token值
session.post("http://www.renren.com/PLogin.do", data = data)
# 4. session包含用户登录后的Cookie值，可以直接访问那些登录后才可以访问的页面
response = session.get("http://www.renren.com/959734232/profile")
# 6. 打印响应内容
print (response.text)
```

## 处理HTTPS请求 SSL证书验证

*   Requests也可以为HTTPS请求验证SSL证书：
*   要想检查某个主机的SSL证书，你可以使用 verify 参数（也可以不写）默认为verify=True
*   [CA证书](https://baike.baidu.com/item/ca%E8%AF%81%E4%B9%A6/10028741?fr=aladdin)
*   [SSL 证书验证](http://docs.python-requests.org/zh_CN/latest/user/advanced.html#ssl)
```
# coding:utf-8
import requests
response = requests.get("https://www.baidu.com/", verify=True)
# 也可以省略不写
# response = requests.get("https://www.baidu.com/")
print (response.text)
====
如果SSL证书验证不通过，或者不信任服务器的安全证书，则会报出SSLError，
据说 12306 证书是自己做的：
---------------
# coding:utf-8
import requests
response = requests.get("https://www.12306.cn/mormhweb/")
print (response.text)
如果我们想跳过 12306 的证书验证，把 verify 设置为 False 就可以正常请求了。
response = requests.get("https://www.12306.cn/mormhweb/", verify = False)
```
```
request并不仅仅只有这么一点功能，大家可以看一下中文文档。这里只是列举了一些常用的。
个人理解，仅供参考。
```
