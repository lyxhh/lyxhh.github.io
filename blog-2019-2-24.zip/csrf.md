---
title: CSRF
date: 2017-12-12 17:33:14
categories:
	- OWASP
tags:
	- CSRF
---

CSRF简单使用<!-- more -->


CSRF工作原理
```
攻击者发现CSRF漏洞——构造代码——发送给受害人——受害人打开——受害人执行代码——完成攻击
```

CSRF的攻击一直是管理员自己实现的，攻击者只负责了构造代码。
```
‍‍举个例子:
受害者的网址是http://192.168.189.159:8000/，
攻击者的网址是 http://192.168.189.137:80/，

攻击者想要在某个网站(网站是某个开源CMS)添加上另一个管理员，

这里肯定要开源的CMS，不开源你没源码怎么构造代码？

这时攻击者发现了这个开源CMS后台添加管理员时并没有加入验证码或则token，
只需要输入要添加的管理员账号和密码点击确定就可以添加管理员账户了。

这时攻击者在自己的服务器上建立了一个index.html文件(地址是http://192.168.189.137:80/index.html

然后就给网站管理员发邮件等等，诱使管理员打开http://192.168.189.137:80/index.html，

当管理员打开后（这时管理员正在网站后台，或则管理员的session并没有失效的话），

就可以神不知鬼不觉的在网站后台添加了一个管理员账户。
```

下面用到一款工具
[csrf测试工具](https://www.owasp.org/index.php/Category:OWASP_CSRFTester_Project)‍‍

因为工具监听的是8008，所以要把数据发到这个端口，先设置一层浏览器代理。

<iframe height=298 width=510 src='http://player.youku.com/embed/XMzIyNTcwNzc2OA==' frameborder=0 'allowfullscreen'></iframe>‍‍