---
title: python正则表达式
date: 2017-11-13 10:17:19
categories:
	- Python
tags:
	- python
---

python正则表达式的简单使用<!-- more -->

```
正则表达式使用单个字符串来描述、匹配一系列匹配某个句法规则的字符串。
```

## re
```
在Python中需要通过正则表达式对字符串进行匹配的时候，
可以使用re模块

re.match  尝试在字符串的开头应用该模式， 
	   能够匹配出以xxx开头的字符串

re.search  扫描字符串，寻找符合正则的，

```
![matchseach](http://owrmua5nw.bkt.clouddn.com/matchseach.png)



## 表示字符
![re1](http://owrmua5nw.bkt.clouddn.com/re1.png)

* .
![repot](http://owrmua5nw.bkt.clouddn.com/repot.png)

* \d,\D
![rexied](http://owrmua5nw.bkt.clouddn.com/rexied.png)

* \s,\S
![res](http://owrmua5nw.bkt.clouddn.com/res.png)

* \w,\W
![rew](http://owrmua5nw.bkt.clouddn.com/rew.png)

* []
![rekuohao](http://owrmua5nw.bkt.clouddn.com/rekuohao.png)

```
\d == [0-9]  0-9 ==  0到9 a-z  == a到z
\D == [^0-9]
\w == [a-zA-Z0-9_]
\W == [^a-zA-Z0-9_]

在python正则表达式中，我们可以用反斜杠\来取消正则表达式中的特殊字符的解析，
例如我们想匹配点。 我们可以用\. 来匹配
```


## 表示数量
![re2](http://owrmua5nw.bkt.clouddn.com/re2.png)

* '*','?','+'
![renumber](http://owrmua5nw.bkt.clouddn.com/renumber.png)

* {}
![redakuohao](http://owrmua5nw.bkt.clouddn.com/redakuohao.png)

## 表示边界
![re3](http://owrmua5nw.bkt.clouddn.com/re3.png)

* '^','$'
![restartend](http://owrmua5nw.bkt.clouddn.com/restartend.png)

* '\b','\B'
```
单词边界，这是一个只匹配单词的开始和结尾的零宽断言。
“单词”定义为一个字母数字的序列，所以单词的结束指的是空格或者非字母数字的字符。
```

![rexiegangb](http://owrmua5nw.bkt.clouddn.com/rexiegangb.png)


## 匹配分组
![re4](http://owrmua5nw.bkt.clouddn.com/re4.png)

* "|"
![reor](http://owrmua5nw.bkt.clouddn.com/reor.png)

* "()"
![group1](http://owrmua5nw.bkt.clouddn.com/group1.png)
```
group() 返回匹配的字符串
start() 返回匹配的开始位置
end()   返回匹配的结束位子
span()  返回一个元祖表示匹配位置(开始，结束)
```

* "\number"
![renum](http://owrmua5nw.bkt.clouddn.com/renum.png)

* "(?P<name>)" 取别名,"(?P=name)" 引用别名
![reyinyong](http://owrmua5nw.bkt.clouddn.com/reyinyong.png)


## 原始字符串
```
与大多数编程语言相同，正则表达式里使用"\"作为转义字符
即
\\ 转义成 \ 
\\\\ 转义成 \\
Python中字符串前面加上 r 表示原生字符串，

Python里的原生字符串很好地解决了这个问题，
有了原始字符串，你再也不用担心是不是漏写了反斜杠，写出来的表达式也更直观。
```
![rexier](http://owrmua5nw.bkt.clouddn.com/rexier.png)

## re模块的其他函数

* findall,finditer
```
 findall 遍历字符串，找到正则表达式匹配的所有位置，并以列表的形式返回

 finditer 遍历字符串，找到正则表达式匹配的所有位置，并以迭代器的形式返回
```
![findalliter](http://owrmua5nw.bkt.clouddn.com/findalliter.png)

* sub(替换成这个，匹配这个内容[,count=0])
```
 找到所有匹配的子字符串，并替换为新的内容
 count 指定最多替换的次数，必须是一个非负值。
 默认值是 0，意思是替换所有找到的匹配。
```

* split([,maxsplit=0])
```
 在正则表达式匹配的地方进行分割，并返回一个列表
 maxsplit  参数来设置分割的数量。
 如果maxsplit的值是非 0，
 表示至多有 maxsplit 个分割会被处理，剩下的内容作为列表的最后一个元素返回。
 
```
![subsplit](http://owrmua5nw.bkt.clouddn.com/subsplit.png)

## 贪婪和非贪婪

```
Python里数量词

默认是贪婪的 总是尝试匹配尽可能多的字符；

非贪婪 总是尝试匹配尽可能少的字符。

在"*","?","+","{m,n}"后面加上？，使贪婪变成非贪婪。
```
![tanlan](http://owrmua5nw.bkt.clouddn.com/tanlan.png)

```
我们可以看到在贪婪模式下，re必须从字符串的尾部一个字符一个字符回溯，直到找到第一个匹配的。

在找ip中 re从尾部回溯，\d+ 我们只需要给1个即可满足匹配条件，因此。匹配到2.168.1.1

在找标签中，从尾部回溯找第一个>,结果找到了<title>的>,
而不是<html>的>,当非贪婪时，从头部开始找第一个>,也就找到了<html>的>


注意，使用正则表达式分析 HTML 和 XML 是很痛苦的。
当你编写一个正则表达式去处理所有可能的情况时，你会发现 HTML 和 XML 总会打破你的“规则”，
这让你很头疼......像这样的话，
建议使用 HTML 和 XML 解析器来处理更合适。
```