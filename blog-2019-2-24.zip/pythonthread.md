---
title: Python Thread
date: 2017-10-29 08:45:55
categories:
	- Python
tags:
	- python
---

Python 多线程个人理解 <!-- more -->

## 什么是线程
```
一个软件就是一个进程，例如qq，
一个qq里面多个聊天窗口 一个聊天窗口就是一个线程。

进程是系统进行资源分配和调度的一个独立单位.
线程是CPU调度和分派的基本单位

一个程序至少有一个进程,一个进程至少有一个线程.

线程的划分尺度小于进程(资源比进程少)，使得多线程程序的并发性高。

进程在执行过程中拥有独立的内存单元，而多个线程共享内存，从而极大地提高了程序的运行效率

线程不能够独立执行，必须依存在进程中
```
![threadguocheng](http://owrmua5nw.bkt.clouddn.com/threadguocheng.png)

## 单线程

![onethread](http://owrmua5nw.bkt.clouddn.com/onethread.gif)

## 多线程
![threads](http://owrmua5nw.bkt.clouddn.com/threads.gif)

```
使用了多线程并发的操作，可以明显的看出花费时间要短很多
创建好的线程，需要调用start()方法来启动
也可以看出 主线程会等待所有的子线程结束后才结束
```

## 多线程的创建方式

```
python的thread模块是比较底层的模块，
python的threading模块是对thread做了一些包装的，
可以更加方便的被使用
```

### 第一种就是上图的Thread 
```
如果函数有参数，
Thread(target=function_name, args=(arg1,arg2))
参数是元祖类型，需要注意若只有一个参数不要忘了加逗号。
```

### 继承threading.Thread

```
start方法本质上是调用了run函数。
因此我们重写run方法即可。
```
![threadsclass](http://owrmua5nw.bkt.clouddn.com/threadsclass.gif)


## 线程的执行顺序
![threadshunxu](http://owrmua5nw.bkt.clouddn.com/threadshunxu.gif)

```
线程的执行顺序是不确定的。
当线程的run()方法结束时该线程完成。
每个线程一定会有一个名字，尽管上面的例子中没有指定线程对象的name，但是python会自动为线程指定一个名字。
```

## 多线程-共享全局变量
![theadgloba](http://owrmua5nw.bkt.clouddn.com/theadgloba.gif)

```
在一个进程内的所有线程共享全局变量，能够在不使用其他方式的前提下完成多线程之间的数据共享

缺点就是，线程是对全局变量随意遂改可能造成多线程之间对全局变量的混乱（即线程非安全）
```

## 多线程-非共享全局变量
```
在多线程开发中，全局变量是多个线程都共享的数据，
而局部变量等是各自线程的，是非共享的
因此非全局变量不需要加锁
```

## 线程非安全
![thead01](http://owrmua5nw.bkt.clouddn.com/thead01.png)

```
假设cpu先选择执行thread01，
即执行num+1 等价于 0+1=1 
当要执行赋值语句 num=1的时候 
cpu突然把thread01踢出去了，毕竟cpu要雨露均沾嘛
执行thread02 即thread01 num=1 这个语句没有执行，
当执行thread02的时候 num还是等于0 于是 num+1 等价于 0+1 
这时候cpu又把thread02踢出去，
执行thread01的赋值语句，这时num=1，
当执行thread02赋值语句时，num也是等于1，
也就是说明明thread01和thread02 都完成了1次加1工作，
但结果仍然是num=1。
原因就在于你写的 num = num+1 这语句 不见得操作系统从头到尾执行完，有可能刚执行完一半就把你赶出去了。
因此答案不是我们预期的200w
```
![threadsecurity](http://owrmua5nw.bkt.clouddn.com/threadsecurity.gif)

### 解决思路
```
可以通过线程同步来进行解决

编程中的同步就是现实中的异步，
现实中的异步  做完一件事在做另一件事，

最简单的同步机制就是引进互斥锁
互斥锁为资源引入一个状态：锁定/非锁定。

某个线程要更改共享数据时，先将其锁定，此时资源的状态为“锁定”，
其他线程不能更改；直到该线程释放资源，将资源的状态变成“非锁定”，
其他的线程才能再次锁定该资源。
互斥锁保证了每次只有一个线程进行写入操作，从而保证了多线程情况下数据的正确性
```

```
threading模块中定义了Lock类，可以方便的处理锁定：

# 创建锁
mutex = threading.Lock()
# 锁定
mutex.acquire([blocking])
# 释放
mutex.release()

锁定方法acquire可以有一个blocking参数。

如果设定blocking为True，则当前线程会堵塞，直到获取到这个锁为止（默认为True）

如果设定blocking为False，则当前线程不会堵塞
```
![lock](http://owrmua5nw.bkt.clouddn.com/lock.gif)

```
锁的好处：

确保了某段关键代码只能由一个线程从头到尾完整地执行
锁的坏处：

阻止了多线程并发执行，包含锁的某段代码实际上只能以单线程模式执行，效率就大大地下降了

由于可以存在多个锁，不同的线程持有不同的锁，并试图获取对方持有的锁时，可能会造成 死锁
```

## 死锁
```
即锁1解锁的条件是锁2要解锁

但是锁2解锁的条件又是锁1要解锁

```
![deathlock](http://owrmua5nw.bkt.clouddn.com/deathlock.gif)

### 解决死锁
```
如何避免死锁？
1.创建锁的时候加延时
2.程序设计时要尽量避免（银行家算法）百度一下。

Lock(timeout=2)延时2秒，如果2秒还没有解锁，就不继续等待
```
![death02](http://owrmua5nw.bkt.clouddn.com/death02.gif)

![help1](http://owrmua5nw.bkt.clouddn.com/help1.png)

![timeout](http://owrmua5nw.bkt.clouddn.com/timeout.png)


## 同步的应用

```
使用互斥锁完成多个任务，有序的进程工作
```
![tongbu](http://owrmua5nw.bkt.clouddn.com/tongbu.gif)

## ThreadLocal

```
如果你嫌函数调用时传参很麻烦，又不想用全局变量，
那么可以利用threadlocal进行传参。
ThreadLocal最常用的地方就是为每个线程绑定一个数据库连接，HTTP请求，用户身份信息等
```
![threadlocal](http://owrmua5nw.bkt.clouddn.com/threadlocal.png)

## GIL 全局解释器锁

```
实际上python的多线程是个假的。
因为GIL的影响，
解决：
关键部分用c语言编写。
这里我们用htop来检测。
sudo apt-get install htop
```

![gil](http://owrmua5nw.bkt.clouddn.com/gil.gif)

* * * 
```
从上面这个gif我们可以看到我的双核cpu的占有率并没有到100%，
而是两个加起来达到了100%，即跟单核cpu没什么区别。
如果换成是多进程的话，则占有率两个都为100%。
```

![pool](http://owrmua5nw.bkt.clouddn.com/pool.gif)