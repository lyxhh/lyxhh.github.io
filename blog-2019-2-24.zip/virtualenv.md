---
title: Python3虚拟环境安装
date: 2017-11-01 22:16:00
categories:
	- Python
tags:
	- environment
---
ubuntu下Python3虚拟环境的安装  <!-- more -->

```
1.升级pip3
pip3 install --upgrade pip
```

```
2.安装虚拟环境virtualenv
sudo pip3 install virtualenv
```

```
3.安装虚拟环境管理
sudo easy_install virtualenvwrapper
也可以用pip3安装
```

```
4.创建目录用来存放虚拟环境
    mkdir $HOME/.virtualenvs
5.在~/.bashrc中添加行：
    export WORKON_HOME=$HOME/.virtualenvs
    source /usr/local/bin/virtualenvwrapper.sh
6.运行:
    source ~/.bashrc
```

```
mkvirtualenv [虚拟环境名称]  创建python虚拟环境

mkvirtualenv -p /usr/bin/python3.4(python安装目录，这里写的是ubuntu默认安装路径，) [虚拟环境名称]
mkvirtualenv -p /usr/bin/python2.7 [虚拟环境名称]  
-p 可以指定python2解释器还是python3解释器。

workon [虚拟环境名称]   选择python虚拟环境
deactivate         退出虚拟环境 
rmvirtualenv [虚拟环境名称]   删除(慎用) 
```

网上错误的太多了，每次弄个环境都要找半天，弄得头晕死了 擦。