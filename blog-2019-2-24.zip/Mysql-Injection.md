---
title: Mysql Injection
date: 2017-10-03 20:50:13
categories:
	- Sql Injection
tags:
	- Mysql Injection
---

1.学习手工注入能更好的了解sql注入的原理而不会知其然而不知其所以然。<!-- more -->
2.在waf横行的年代，如果你连手工注入都不懂，又何谈绕过waf进行注入呢。
3.工具是死的，

# Mysql Injection

## sql注入的原理
```
Web Application 数据传输中，接受变量传递的值未进行过滤导致直接带入数据库查询。
```

## sql注入对于渗透的作用
```
根据权限的不用，所能执行的操作也不同，
最基本的权限也可以获取数据(例如 网站数据库的账号密码等)
```

## sql注入特性
```
攻击方法由数据库类型决定
攻击结果由数据库类型决定
```

## sql注入的分为两大类
```
1.数字型 2.字符型
很多诸如post，cookie，http头注入等只是提交的方式不同，本质还是属于这两大类。
搜索型也属于字符型，而数字型和字符型最大的区别在于字符型注入要闭合单引号，而搜索型多闭合个%号即可。
```

## Mysql5.0及其以上版本的注入
```
5.0以上的注入属于有根据的注入，
5.0开始自带information_schemas
本章将讲述5.0以上的注入。
```
Mysql的函数注入常用函数
```
version() 显示数据库版本
user() 显示当前连接数据库的用户
database()显示当前使用的数据库 等一些函数
```

mysql5.0以上的新特性
```
Information_schema.schemata 存储mysql下所有的数据库
Information_schema.tables  存储mysql下所有的表名
Information_schema.columns 存储mysql下所有的列名
Table.schema 表名来自哪个数据库
Column.name 列名
Table.name  表名
Schema.name 数据库名
符号"."代表下一级的意思代表下一级的意思
```

mysql数据库的层次
![databases](http://owrmua5nw.bkt.clouddn.com/access.png)

## mysql注入过程分析

如果连接mysql数据库的是root权限，那么则有权限查看其他数据库。
![database](http://owrmua5nw.bkt.clouddn.com/database.png)
如果只爆出来一个 可以加上group_concat()函数

猜表

![tables](http://owrmua5nw.bkt.clouddn.com/table%20concat.png)
test也可以16进制编码，编码不用单引号。
```
http://127.0.0.1/testsql.php?x=1 UNION SELECT group_concat(table_name),2,3,4,5,6,7,8 from information_schema.tables  where  table_schema='test'
意思是:
获取所有的表名从储存mysql下所有的表中获取，条件是数据库名为test的，
即从储存所有的表中取出属于test数据库的表。
其他的类似理解，
```

猜列

![columns](http://owrmua5nw.bkt.clouddn.com/column.png)
```
http://127.0.0.1/testsql.php?x=1 UNION SELECT group_concat(column_name),2,3,4,5,6,7,8 from information_schema.columns where table_name='manage'
```

猜数据

![data](http://owrmua5nw.bkt.clouddn.com/data.png)

## 如何防止sql注入。
```
既然我们知道了sql注入是由于参数未进行过滤而直接带入数据库查询而产生的，
那么防御也就是把非法参数过滤，那么怎么过滤呢
```

### 数字型的过滤

 判断接受的参数是否为数字，如果是则继续执行，如果不是则用JavaScript弹窗提示非法字符即可。

### 字符型过滤

 可以使用正则过滤，如果遇到'单引号 "双引号 \反斜线 空字符等 则替换为空，原则上只要我们让攻击者的sql语句不能闭合我们的单引号即可。

## Mysql注入的高级应用。
```
前提条件是需要root权限,以及魔术引号关闭的状态。
root权限支持读和写，那我们利用的前提是知道网站的绝对路径。
```

### 如何获得网站的绝对路径

1.报错显示，即 使网页报错，比如常见的单引号报错等，
![error](http://owrmua5nw.bkt.clouddn.com/%E5%8D%95%E5%BC%95%E5%8F%B7.png)
2.读取Apache,iis等平台配置文件
3.读取脚本语言配置文件，例如php.ini
4.根据同服的其他站点的报错显示进行猜测。
5.探针文件，如phpinfo。
6.编辑器错误日志。
7.google hack
等其他方法。

### 利用Mysql root权限进行读文件
```
load_file()函数进行读取。
这里要注意文件的路径要么
一个/斜杠 
要么两个\\反斜杠,
一个\斜杠会被转义，
```

![read](http://owrmua5nw.bkt.clouddn.com/read.png)

### [](#root权限写文件 "root权限写文件")root权限写文件

![write](http://owrmua5nw.bkt.clouddn.com/1111.gif)
```
既然我们可以写文字进去，那么我们是不是也可以把我们的一句话写进去呢？
注意：
1.可编码写入，编码不用单引号，写入的文本用Hex编码，
2.写入的绝对路径用Url编码，注意带上单引号进行编码。
2.写入文件的函数不只into dumpfile 还可以用 into outfile写 用法相同，
```

个人理解，仅供参考。