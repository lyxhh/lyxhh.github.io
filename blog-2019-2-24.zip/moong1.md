---
title: MongoDB 
date: 2017-10-31 19:35:52
categories:
	- Database
tags:
	- MoogoDB
---

MongoDB 是一个基于分布式 文件存储的NoSQL数据库<!-- more -->

# 安装
```
根据业界规则，偶数为稳定版，如1.6.X，奇数为开发版，如1.7.X
32bit的mongodb最大只能存放2G的数据，64bit就没有限制
官方并不推荐下载包解压安装。

安装自行参考安装教程

MongoDB实例
默认存储其数据文件/var/lib/mongodb 
日志文件 /var/log/mongodb，并使用mongodb 用户帐户运行。
配置文件 /etc/mongod.conf
默认端口27017

启动
sudo service mongod start

停止
sudo service mongod stop

重启
sudo service mongod restart

mongo 使用终端连接
这个shell就是mongodb的客户端，同时也是一个js的编译器

robomongo  mongodb图形界面管理工具
```

```
安装出错。
This application failed to start because it could not find or load the Qt platform plugin "xcb"
in "".

Available platform plugins are: xcb.

Reinstalling the application may fix this problem.
Aborted (core dumped)
```
```
解决方法。
mkdir ~/robo-backup
mv robo3t-1.1.1-linux-x86_64-c93c6b0/lib/libstdc++* ~/robo-backup/
robo3t-1.1.1-linux-x86_64-c93c6b0/bin/robo3t

```
[安装教程](https://docs.mongodb.com/manual/administration/install-on-linux/)


# 简介
MongoDB将数据存储为一个文档，文档类似于JSON对象，数据结构由键值(key=>value)对组成

## 组成
```
database 数据库

collection 数据库集合 类似mysql的表

document  数据的文档  相当于mysql中的一行数据 
文档就是一个对象，由键值对构成，是json的扩展Bson形式。

field     字段，相当于mysql中的column字段。

index     索引

表连接    不支持

主键      primary MongoDB自动将_id字段设置为主键

三元素：数据库，集合，文档

集合就是关系数据库中的表，存储多个文档

文档对应着关系数据库中的 行

文档，就是一个对象，由键值对构成，是json的扩展Bson形式

ex: {'name':'guojing','gender':'男'}
```

# 基本操作

## 数据库操作

```
db    -查看当前数据库名称
db.stats() -查看当前数据库信息
show dbs   -列出所有在物理上存在的数据库
use  数据库名称   -切换数据库

如果数据库不存在，则指向数据库，但不创建，直到插入数据或创建集合时数据库才被创建

默认的数据库为test，如果你没有创建新的数据库，集合将存放在test数据库中

db.dropDatabase() 删除当前指向的数据库

如果数据库不存在，则什么也不做

```
![mongodatabase](http://owrmua5nw.bkt.clouddn.com/mongodatabase.png)

## 集合操作

```
db.createCollection(name, options) - 集合创建

name是要创建的集合的名称
options是一个文档，用于指定集合的配置
options​​参数是可选的

db.createCollection("lxhsec") - 创建lxhsec的集合

限制集合大小
db.createCollection("lxhsec1", { capped : true, size : 10 } )

参数capped：默认值为false表示不设置上限，值为true表示设置上限
参数size：当capped值为true时，需要指定此参数，表示上限大小，当文档达到上限时，会将之前的数据覆盖，单位为字节

show collections  - 查看当前数据库的集合

db.集合名称.drop() - 删除集合

```
![mongocollection](http://owrmua5nw.bkt.clouddn.com/mongocollection.png)

![mongosize](http://owrmua5nw.bkt.clouddn.com/mongosize.png)

## 数据类型

```
MongoDB中常用的几种数据类型：
Object ID：文档ID
String：字符串，最常用，必须是有效的UTF-8
Boolean：存储一个布尔值，true或false
Integer：整数可以是32位或64位，这取决于服务器
Double：存储浮点值
Arrays：数组或列表，多个值存储到一个键
Object：用于嵌入式的文档，即一个值为一个文档
Null：存储Null值
Timestamp：时间戳
Date：存储当前日期或时间的UNIX时间格式

object id

每个文档都有一个属性，为_id，保证每个文档的唯一性

MongoDB为每个文档提供了一个独特的_id，类型为objectID
也可以自己设置_id

objectID是一个12字节的十六进制数
前4个字节为当前时间戳
接下来3个字节的机器ID
接下来的2个字节中MongoDB的服务进程id
最后3个字节是简单的增量值
```

## 数据操作

```
db.集合名称.insert(document) - 数据插入

db.集合名称.find() - 简单查询
```
![mongodata1](http://owrmua5nw.bkt.clouddn.com/mongodata1.png)

```
db.集合名称.update(     - 更新
   <where>,
   <set>,
   {multi: <boolean>}
)

参数where:查询条件，类似sql语句update中where部分
参数set:更新操作符，类似sql语句update中set部分
参数multi:可选，默认是false，表示只更新找到的第一条记录，值为true表示把满足条件的文档全部更新

指定属性更新，通过操作符$set

db.lxhsec.update({name:"test1"},{$set:{name:"test3"}});

若没有指定字段更新则是全文档更新。
```
![mongodata2](http://owrmua5nw.bkt.clouddn.com/mongodata2.png)

![mongodata3](http://owrmua5nw.bkt.clouddn.com/mongodata3.png)

![mongodata4](http://owrmua5nw.bkt.clouddn.com/mongodata4.png)

![mongodata5](http://owrmua5nw.bkt.clouddn.com/mongodata5.png)

```
删除 
db.集合名称.remove(
   <where>,                              
   {
     justOne: <boolean>
   }
) 
参数where:可选，删除的文档的条件
参数justOne:可选，如果设为true或1，则只删除一条，默认false，表示删除多条           

db.lxhsec.remove({gender:"nan"},{justone:true}); 只删除匹配到的第一条

db.lxhsec.remove({});  全部删除

```
![mongodata7](http://owrmua5nw.bkt.clouddn.com/mongodata7.png)
![mongodata6](http://owrmua5nw.bkt.clouddn.com/mongodata6.png)

## 数据查询

### 基本查询
```

db.集合名称.find({条件文档}) - 简单查询

db.集合名称.findOne({条件文档})  - 查询，只返回第一个

db.集合名称.find({条件文档}).pretty()  - 将结果格式化

```
![find](http://owrmua5nw.bkt.clouddn.com/find.png)

### 比较运算符
```
等于，默认是等于判断，没有运算符
小于$lt
小于或等于$lte
大于$gt
大于或等于$gte
不等于$ne

```
![findbijiao](http://owrmua5nw.bkt.clouddn.com/findbijiao.png)

### 逻辑运算符
```
查询时可以有多个条件，多个条件之间需要通过逻辑运算符连接

逻辑与：默认是逻辑与(and)的关系
逻辑或：使用$or

```
![findandor](http://owrmua5nw.bkt.clouddn.com/findandor.png)

### 范围运算符
```
使用"$in"，"$nin" 判断是否在某个范围内
```
![findin](http://owrmua5nw.bkt.clouddn.com/findin.png)

### 支持正则表达式
```
使用//或$regex编写正则表达式
```
![findre](http://owrmua5nw.bkt.clouddn.com/findre.png)

### 自定义查询
```
使用$where后面写一个js函数，返回满足条件的数据
前面提到过mongodb的shell，就是mongodb的客户端，同时也是一个js的编译器
```
![findzidingyi](http://owrmua5nw.bkt.clouddn.com/findzidingyi.png)


## Limit and Skip
```
方法limit()和skip()可以一起使用，不分先后顺序
```
![findlinitskip](http://owrmua5nw.bkt.clouddn.com/findlinitskip.png)

### Limit

```
limit()方法：用于读取指定数量的文档
db.集合名称.find({条件}).limit(NUMBER)
```
![findlimit](http://owrmua5nw.bkt.clouddn.com/findlimit.png)

### Skip

```
skip()方法：用于跳过指定数量的文档
db.集合名称.find({条件}).skip(NUMBER)
```
![findskip](http://owrmua5nw.bkt.clouddn.com/findskip.png)


## 投影

```

db.集合名称.find({where},{字段名称:1,...})

1.在查询到的返回结果中，只显示必要的字段，而不显示一个文档的所有字段

2.对于需要显示的字段，设置为1即可，不设置即为不显示

3.特殊：对于_id列默认是显示的，如果不显示需要明确设置为0
```
![findtouying](http://owrmua5nw.bkt.clouddn.com/findtouying.png)

## 排序

```
sort()方法，用于对结果集进行排序

db.集合名称.find({where}).sort({字段:1,...})

参数1为升序排列
参数-1为降序排列
```
![findsort](http://owrmua5nw.bkt.clouddn.com/findsort.png)

## 统计个数

```
count()方法  - 用于统计结果集中文档条数

db.集合名称.find({条件}).count() 

也可以写成
db.集合名称.count({条件})
```
![findcount](http://owrmua5nw.bkt.clouddn.com/findcount.png)

## 消除重复
```
distinct() 方法 - 对数据进行去重
db.集合名称.distinct('去重字段',{条件})
```
![finddistinct](http://owrmua5nw.bkt.clouddn.com/finddistinct.png)

# 高级操作

## 聚合(aggregate)操作
```
类似sql中的sum()、avg()

db.集合名称.aggregate([{管道:{表达式}}])
```

* 管道
```
管道在Unix和Linux中一般用于将当前命令的输出结果作为下一个命令的输入

ps ajx | grep mongo

在mongodb中，管道具有同样的作用，文档处理完毕后，通过管道进行下一次处理

```

* 表达式
```
处理输入文档并输出
语法: 表达式:'$列名'

常用表达式
$sum：计算总和，$sum:1同count表示计数
$avg：计算平均值
$min：获取最小值
$max：获取最大值
$push：在结果文档中插入值到一个数组中
$first：根据资源文档的排序获取第一个文档数据
$last：根据资源文档的排序获取最后一个文档数据
```

### $group
```
$group：将集合中的文档分组，可用于统计结果
Group by null 将集合中所有文档分为一组
$$ROOT可以将整个文档内容加入到结果集的数组中
```
![mongoaggregate1](http://owrmua5nw.bkt.clouddn.com/mongoaggregate1.png)

![mongoaggregate2](http://owrmua5nw.bkt.clouddn.com/mongoaggregate2.png)

### $match
```
$match：过滤数据，只输出符合条件的文档
```
![mongoaggregatematch1](http://owrmua5nw.bkt.clouddn.com/mongoaggregatematch1.png)

### $project
```
$project：显示你想显示的字段，类似find投影功能。
多个聚合一起使用时，可以用project显示需要显示的字段
```
![mongoaggregateproject](http://owrmua5nw.bkt.clouddn.com/mongoaggregateproject.png)

### $sort
```
$sort：将输入文档排序后输出
1升序，
-1降序
```
![mongoaggregatesort](http://owrmua5nw.bkt.clouddn.com/mongoaggregatesort.png)

### $limit $skip

```
$limit：限制聚合管道返回的文档数
$skip：跳过指定数量的文档，并返回余下的文档
```
![mongoaggregateskip](http://owrmua5nw.bkt.clouddn.com/mongoaggregateskip.png)

### $unwind
```
$unwind：将数组类型的字段进行拆分
db.集合名称.aggregate([{$unwind:'$字段名称'}])
```
![mongoaggregateunwind](http://owrmua5nw.bkt.clouddn.com/mongoaggregateunwind.png)
![mongoaggregateunwind2](http://owrmua5nw.bkt.clouddn.com/mongoaggregateunwind2.png)

## 备份与恢复
### 备份
```
mongodump -h dbhost -d dbname -o dir
-h：服务器地址，也可以指定端口号
-d：需要备份的数据库名称
-o：备份的数据存放位置，此目录中存放着备份出来的数据
```
![back](http://owrmua5nw.bkt.clouddn.com/back.png)

### 恢复
```
mongorestore -h dbhost -d dbname --dir dbdirectory
-h：服务器地址
-d：需要恢复的数据库实例
--dir：备份数据所在位置
```
![restore](http://owrmua5nw.bkt.clouddn.com/restore.png)

## 索引

```
建立唯一索引，实现唯一约束，不重复
db.集合.ensureIndex({属性:1},{"unique":true})

建立联合索引，对多个熟悉建立一个索引。按照find()出现的顺序
db.集合.ensureIndex({属性:1,属性:1})

1表示升序
-1表示降序


查看文档所有索引
db.集合.getIndexes()

删除所有索引
db.集合.dropIndexes()

删除指定索引
db.集合.dropIndex('索引名称')


用explain('executionStats')方法进行查询性能分析

```

```
1. 先建立10万条数据，mongoshell也是一个js解释器，用js循环
for(i=0;i<100000;i++){db.testindex.insert({name:'testindex'+i,age:i})}
```

2.执行一条查询语句，并用expalin方法
![index1](http://owrmua5nw.bkt.clouddn.com/index1.png)

3.建立索引
![index2](http://owrmua5nw.bkt.clouddn.com/index2.png)

4.再次执行查询语句
![index3](http://owrmua5nw.bkt.clouddn.com/index3.png)

删除索引
![index4](http://owrmua5nw.bkt.clouddn.com/index4.png)

## 安全性

```

常用系统角色如下：
root：最高权限，可操作所有数据库
Read：允许用户读取指定数据库
readWrite：允许用户读写指定数据库

一般在开发中我们是拿不到root权限的账号的，只能拿到一个该项目数据库的读写账户。

如何进行权限设置呢

1.先创建超级管理员

创建超级管理用户
use admin
db.createUser({
    user:'admin',
    pwd:'123',
    roles:[{role:'root',db:'admin'}]
})
```
![security](http://owrmua5nw.bkt.clouddn.com/security.png)


2.修改配置文件，开启验证
sudo vi /etc/mongod.conf

原始文件
![security1](http://owrmua5nw.bkt.clouddn.com/security1.png)

修改成
![security1.5](http://owrmua5nw.bkt.clouddn.com/security1.5.png)

3.修改配置后要重启服务
```
sudo service mongod restart  重启服务
```

![security2](http://owrmua5nw.bkt.clouddn.com/security2.png)

4.使用root权限账户连接

`mongo -u 'lxhsec' -p  --authenticationDatabase 'admin'`

![security3](http://owrmua5nw.bkt.clouddn.com/security3.png)

5.创建普通账户文件
```
db.createUser({
    user:'test',
    pwd:'root',
    roles:[{role:'readWrite',db:'test'}]
})

role: 设置的权限大小
db：设置哪个数据库权限

即，设置一个test用户，密码为root，
这个账户给数据库test使用，权限的大小为读写权限
```
![security4](http://owrmua5nw.bkt.clouddn.com/security4.png)

6.使用test用户连接测试下权限。
![security5](http://owrmua5nw.bkt.clouddn.com/security5.png)

## 复制
```
为什么要复制

数据备份
数据灾难恢复
读写分离
高（24* 7）数据可用性
无宕机维护
副本集对应用程序是透明


复制的工作原理

复制至少需要两个节点A、B
A是主节点，负责处理客户端请求
其余的都是从节点，负责复制主节点上的数据
主节点记录在其上的所有操作，
从节点定期轮询主节点获取这些操作，
然后对自己的数据副本执行这些操作，
从而保证从节点的数据与主节点一致

主节点与从节点进行数据交互保障数据的一致性

复制的特点

N 个节点的集群
任何节点可作为主节点
所有写入操作都在主节点上
自动故障转移
自动恢复


rs是mongod 提供给我们管理副本集的对象

这里用xshell演示

这里以 27018做主，27019做从

删除从节点
rs.remove('127.0.0.1:27018')
```

1.设置完服务器之后，服务器停在那里，等待客户端连接。
![mongo1](http://owrmua5nw.bkt.clouddn.com/mongo1.png)

2.继续设置一台mongod服务器。
![mongo2](http://owrmua5nw.bkt.clouddn.com/mongo2.png)

3.开启两个终端，各自连接一个mongod
![mongo3](http://owrmua5nw.bkt.clouddn.com/mongo3.png)

![mongo4](http://owrmua5nw.bkt.clouddn.com/mongo4.png)

4.初始化
```
哪个做主服务器，就初始化哪个
rs.initiate()  初始化
```
![mongo5](http://owrmua5nw.bkt.clouddn.com/mongo5.png)

5.添加从服务器
![mongo6](http://owrmua5nw.bkt.clouddn.com/mongo6.png)

6.测试
![mongo7](http://owrmua5nw.bkt.clouddn.com/mongo7.png)
![mongo8](http://owrmua5nw.bkt.clouddn.com/mongo8.png)

7.主从切换
```
当主服务器挂掉之后，副服务器会变成主服务器
这里我们把主服务器27018的强制退出。
可以看到shell连接的主键命令也变了。
之后把shell也退出，就剩下原来副服务器存在。
```
![mongo9](http://owrmua5nw.bkt.clouddn.com/mongo9.png)
![mongo10](http://owrmua5nw.bkt.clouddn.com/mongo10.png)
![mongo11](http://owrmua5nw.bkt.clouddn.com/mongo11.png)
![mongo12](http://owrmua5nw.bkt.clouddn.com/mongo12.png)

# 与python交互

[官方文档](http://api.mongodb.com/python/current/tutorial.html)