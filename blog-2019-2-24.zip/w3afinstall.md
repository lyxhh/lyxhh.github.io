---
title: W3af install
date: 2017-11-05 21:37:32
categories:
	- tools
tags:
	- tools
---
这破工具安装了我一天，官方给的安装方式太简单了。<!-- more -->

```
1.apt-get update
2.easy_install --upgrade pip  
3.cd 切换到你想要安装的目录 
4.git clone --depth 1 https://github.com/andresriancho/w3af.git  kail32位自带git，64位没安装会给出安装命令。
5.下载完后切换到w3af下 执行./w3af_gui，如下图
```
![w3af1](http://owrmua5nw.bkt.clouddn.com/w3af1.png)

```
6. 之后在我们tmp目录下生成了一个文件，里面有w3af需要的包
7. cd /tmp
8. ./w3af_dependency_install.sh
9. 之后坑来了。。出现错误如下图，这时我们先安装lxml
```
![w3af2](http://owrmua5nw.bkt.clouddn.com/w3af2.png)

```
之后我们进入w3af修改下参数
cd w3af
修改 leafpad w3af/core/controllers/dependency_check/requirements.py 文件内容如下：
PIPDependency('OpenSSL', 'pyOpenSSL', '17.3.0'),
```

```
这个一定要改，不然会出现我们自己安装会疯狂报。
AttributeError: 'module' object has no attribute 'SSL_ST_INIT'
这个错误，

之后运行w3af_gui 它会提示我们没有安装pyopenssl这个包，然后根据它的提示
安装17.3.0这个版本的包，

```
![w3af4](http://owrmua5nw.bkt.clouddn.com/w3af4.png)

```
之后继续运行./w3af_gui
提示我们少包，继续安装
```
![w3af5](http://owrmua5nw.bkt.clouddn.com/w3af5.png)

下载
```
wget http://ftp.br.debian.org/debian/pool/main/p/pywebkitgtk/python-webkit_1.1.8-2_i386.deb

wget http://ftp.br.debian.org/debian/pool/main/w/webkitgtk/libwebkitgtk-1.0-0_2.4.11-3_i386.deb

wget http://ftp.br.debian.org/debian/pool/main/w/webkitgtk/libjavascriptcoregtk-1.0-0_2.4.11-3_i386.deb

wget http://ftp.br.debian.org/debian/pool/main/p/python-support/python-support_1.0.15_all.deb
```
安装

```
apt-get install libpango1.0-dev
```
![w3af6](http://owrmua5nw.bkt.clouddn.com/w3af6.png)

```
之后再运行一次 apt-get install libpango1.0-dev
接着

dpkg -i libjavascriptcoregtk-1.0-0_2.4.11-3_i386.deb 
dpkg -i libwebkitgtk-1.0-0_2.4.11-3_i386.deb 
dpkg -i python-support_1.0.15_all
dpkg -i python-webkit_1.1.8-2_i386.deb 

验证webkit安装成功 

进入python shell
import webkit 没报错则成功

之后继续运行./w3af_gui
还是报错，看图操作
```
![w3af7](http://owrmua5nw.bkt.clouddn.com/w3af7.png)
![w3af8](http://owrmua5nw.bkt.clouddn.com/w3af8.png)

成功
```
之后继续运行./w3af_gui，发现成功了
```
![w3af9](http://owrmua5nw.bkt.clouddn.com/w3af9.png)

上面是kail32位的。
64位的
```
wget http://ftp.br.debian.org/debian/pool/main/p/pywebkitgtk/python-webkit_1.1.8-3_amd64.deb

wget http://ftp.br.debian.org/debian/pool/main/w/webkitgtk/

libjavascriptcoregtk-1.0-0_2.4.11-3_amd64.deb
wget http://ftp.br.debian.org/debian/pool/main/p/python-support/python-support_1.0.15_all.deb

wget http://ftp.br.debian.org/debian/pool/main/w/webkitgtk/libwebkitgtk-1.0-0_2.4.11-3_amd64.deb
```

```
dpkg -i libjavascriptcoregtk-1.0-0_2.4.11-3_amd64.deb
dpkg -i python-support_1.0.15_all.deb
dpkg -i libwebkitgtk-1.0-0_2.4.11-3_amd64.deb
dpkg -i python-webkit_1.1.8-3_amd64.deb
```