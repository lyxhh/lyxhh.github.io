---
title: Redis
date: 2017-11-27 18:42:25
categories:
	- Database
tags:
	- Redis
---

Redis 采用运行在 内存中的数据集工作方式<!-- more -->

# 简介

## 安装

[redis官方网站](https://redis.io/)，推荐下载稳定版本(stable)

```
1.解压
tar zxvf redis-3.2.5.tar.gz

2.进入解压后的redis目录

3.生成
sudo make

4.测试
sudo make test

5.安装
sudo make install 

运行服务端
redis-server

运行客户端
redis-cli

运行命令
ping

返回PONG

切换数据库命令
select 数据库名

redis 默认16个数据库 从0~15.

```

## 配置
```
redis.conf为配置文件,通常在redis的目录下

绑定地址：如果需要远程访问，可将此行注释
bind 127.0.0.1

端口，默认为6379
port 6379

是否以守护进程运行
如果以守护进程运行，则不会在命令行阻塞，类似于服务

如果以非守护进程运行，则当前终端被阻塞，无法使用
推荐改为yes，以守护进程运行
daemonize no|yes

数据文件
dbfilename dump.rdb
默认储存在当前目录

若以守护进程方式配置
需要以配置文件方式启动，

推荐指定配置文件启动
sudo redis-server redis.conf绝对路径 

停止redis服务

ps ajx|grep redis

sudo kill -9 redis的进程id

```
![config1](http://owrmua5nw.bkt.clouddn.com/config1.png)

![config2](http://owrmua5nw.bkt.clouddn.com/config2.png)

# 数据操作

```
redis是key-value的数据，因此每个数据都是一个键值对

键的类型是字符串

值的类型分为五种：

字符串string   实际操作中一般字符串的操作就足够使用了。
哈希hash
列表list
集合set
有序集合zset
```
数据操作的全部命令[官方中文文档](http://redis.cn/commands.html)

## String
```
string是redis最基本的类型

最大能存储512MB数据

string类型是二进制安全的，即可以为任何数据，比如数字、图片、序列化对象等

在redis不要理解string类型为字符串，它不仅可以存字符串，还可以存图片的二进制序列化等序列化对象，

它的唯一要求，最大只能存储512MB数据
```

### 设置 and 获取

* 设置键值
```
set key value
```
![set1](http://owrmua5nw.bkt.clouddn.com/set1.png)

* 设置键值及过期时间，以秒为单位 
```
SETEX key time value
操作session时有用。
```
![set2](http://owrmua5nw.bkt.clouddn.com/set2.png)

* 设置多个键值
```
MSET key value [key value ...]
```

* 根据键获取值
```
如果不存在此键则返回nil
GET key
```

* 根据多个键获取多个值
```
MGET key [key ...]
```
![get1](http://owrmua5nw.bkt.clouddn.com/get1.png)

### 运算
```
要求值必须是数字
```

* 将key对应的value加1
```
INCR key
```

* 将key对应的value加整数
```
INCRBY key increment
```

* 将key对应的value减1
```
DECR key
```

* 将key对应的value减整数
```
DECRBY key decrement
```
![yunsuan](http://owrmua5nw.bkt.clouddn.com/yunsuan.png)

### 其他

* 追加值
```
APPEND key value
```

* 获取值长度
```
STRLEN key
```
![orther](http://owrmua5nw.bkt.clouddn.com/orther.png)

## 键命令

* 查找键，参数支持正则,* 代表通配符
```
KEYS regular
```

* 判断键是否存在，如果存在返回1，不存在返回0
```
EXISTS key [key ...]
```
* 查看键对应的值的类型
```
TYPE key
```

* 删除键及对应的值，可删除多个
```
DEL key [key ...]
```

* 设置过期时间，以秒为单位
```
创建时没有设置过期时间，之后也可以设置。
创建时没有设置过期时间则一直存在，直到使用使用DEL移除

EXPIRE key seconds
```

* 查看 离过期时间的还有多远，以秒为单位，到0时删除。
```
TTL key
```
![key](http://owrmua5nw.bkt.clouddn.com/key.png)

## hash

```
hash用于存储对象，对象的格式为键值对
```

* 设置单个属性
```
HSET key field value
```

* 设置多个属性
```
HMSET key field value [field value ...]
```

* 获取一个属性的值
```
HGET key field
```

* 获取多个属性的值
```
HMGET key field [field ...]
```

* 获取所有属性和值
```
HGETALL key
```

* 获取所有的属性
```
HKEYS key
```
* 返回包含属性的个数
```
HLEN key
* 获取所有值
HVALS key
```

* 判断属性是否存在
```
HEXISTS key field
```

* 删除属性及值
```
HDEL key field [field ...]
可同时删除多个属性。
```

* 返回值的字符串长度
```
HSTRLEN key field
```
![hash](http://owrmua5nw.bkt.clouddn.com/hash.png)

## list

```
列表的元素类型为string

按照插入顺序排序

在列表的头部或者尾部添加元素
```

### 设置
```
LPUSH key value [value ...]
在头部插入数据


在尾部插入数据
RPUSH key value [value ...]

在一个元素的前|后插入新元素
LINSERT key BEFORE|AFTER pivot value


LSET key index value
设置指定索引的元素值,即修改or插入

索引是基于0的下标
索引可以是负数，表示偏移量是从list尾部开始计数，如-1表示列表的最后一个元素

```
![list1](http://owrmua5nw.bkt.clouddn.com/list1.png)

![list2](http://owrmua5nw.bkt.clouddn.com/list2.png)


### 获取
```
LPOP key
移除并且返回 key 对应的 list 的第一个元素

RPOP key
移除并返回存于 key 的 list 的最后一个元素

LRANGE key start stop

返回存储在 key 的列表里指定范围内的元素
start 和 end 偏移量都是基于0的下标
偏移量也可以是负数，表示偏移量是从list尾部开始计数，如-1表示列表的最后一个元素


其他


LTRIM key start stop
裁剪列表，改为原集合的一个子集
start 和 end 偏移量都是基于0的下标
偏移量也可以是负数，表示偏移量是从list尾部开始计数，如-1表示列表的最后一个元素

LLEN key
返回存储在 key 里的list的长度

LINDEX key index
返回列表里索引对应的元素

```
![list3](http://owrmua5nw.bkt.clouddn.com/list3.png)


## set

```
无序集合

元素为string类型

元素具有唯一性，不重复
```

### 设置&获取
```

SADD key member [member ...]
添加元素


获取

SMEMBERS key
返回key集合所有的元素


SCARD key
返回集合元素个数

```
![setlist1](http://owrmua5nw.bkt.clouddn.com/setlist1.png)


### 其它

```
SINTER key [key ...]
求多个集合的交集

SDIFF key [key ...]
求某集合与其它集合的差集

SUNION key [key ...]
求多个集合的合集

SISMEMBER key member
判断元素是否在集合中

```
![setlist2](http://owrmua5nw.bkt.clouddn.com/setlist2.png)


## zset
```
sorted set，有序集合

元素为string类型

元素具有唯一性，不重复

每个元素都会关联一个double类型的score，表示权重，通过权重将元素从小到大排序

元素的score可以相同
```

```
ZADD key score member [score member ...]
添加

ZRANGE key start stop
返回指定范围内的元素

ZCARD key
返回元素个数

ZCOUNT key min max
返回有序集key中，score值在min和max之间成员的个数

ZSCORE key member
返回有序集key中，成员member的score值

```
![zset](http://owrmua5nw.bkt.clouddn.com/zset.png)

```
list set zset 三者的区别
list的顺序是按照插入时的顺序排列，
set 是无序的
zset 是按照权重的大小进行排列。
```


# 高级

## 发布订阅
```
客户端发到频道的消息，将会被推送到所有订阅此频道的客户端

客户端不需要主动去获取消息，只需要订阅频道，这个频道的内容就会被推送过来

即不需要主动请求 完成数据的更新
个人理解 类似于微信公众号。
```

### 消息的格式
```
消息类型，包含三种类型

subscribe，表示订阅成功

unsubscribe，表示取消订阅成功

message，表示其它终端发布消息

当在Pub/Sub以外状态，客户端可以发出任何redis命令

```

```
SUBSCRIBE 频道名称 [频道名称 ...]
订阅

UNSUBSCRIBE 频道名称 [频道名称 ...]
取消订阅
如果不写参数，表示取消所有订阅

PUBLISH 频道 消息
发布

```
![dingyue1](http://owrmua5nw.bkt.clouddn.com/dingyue1.png)

![dingyue2](http://owrmua5nw.bkt.clouddn.com/dingyue2.png)

![dingyue3](http://owrmua5nw.bkt.clouddn.com/dingyue3.png)


## 主从配置
```
一个master可以拥有多个slave，一个slave又可以拥有多个slave，如此下去，形成了强大的多级服务器集群架构

比如，
将ip为192.168.189.154的机器作为主服务器，
将ip为192.168.189.141的机器作为从服务器

设置主服务器的配置
bind 192.168.189.154
设置从服务器的配置
注意：在slaveof后面写主机ip，再写端口，而且端口必须写
bind 192.168.189.141
slaveof 192.168.189.154 6379

在master和slave分别执行info命令，查看输出信息

在master上写数据
set hello world

在slave上读数据
get hello

```
![slave1](http://owrmua5nw.bkt.clouddn.com/slave1.png)

![slave2](http://owrmua5nw.bkt.clouddn.com/slave2.png)

![slave3](http://owrmua5nw.bkt.clouddn.com/slave3.png)

![slave5](http://owrmua5nw.bkt.clouddn.com/slave5.png)

![slave4](http://owrmua5nw.bkt.clouddn.com/slave4.png)


```
redis命令有几百条 我不可能一一列出来，
上面给出了redis的中文文档，需要的时候可自行查询。

个人理解，仅供参考。
```