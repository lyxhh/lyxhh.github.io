---
title: vps搭建属于自己的ssr
date: 2017-10-21 09:55:43
categories:
	- Clutter
tags:
	- environment
---
前言： vps+ssr搭建属于年轻人的专属翻墙通道, 
国内的vpn挂完了，自己搭建一个ssr翻墙还不是美滋滋<!-- more -->

## SSR
```
先介绍一下SSR，它是shadowsocks的升级版，
加入了混淆参数的功能.可用于免流代理等。
```
## VPS
首先要购买国外主机
推荐三个vps商


[digitalocean官网](https://cloud.digitalocean.com)

* 如果你们通过我的[链接](https://m.do.co/c/0388403641e5)注册将获得10$而我也将获得10$.

```
Github 学生包一个比较吸引人的地方就是 DigitalOcean 的 $50 代金券了，
```
[Github学生包](https://education.github.com/)
[申请学生包](https://www.mf8.biz/github-education-pack/)
[DigitalOcean 的学生包代金券使用教程](https://www.mf8.biz/digitalocean-github-pack/)


[vultr](https://my.vultr.com/)
[通过我的链接注册](https://www.vultr.com/?ref=7242026)
```
最便宜2.5$ 500G的流量 支持支付宝。不过支付宝要先冲10$进去。。其他的只要5$s。 China 人傻钱多。。
```


[搬瓦工](https://bwh1.net/vps-hosting.php)
```
最便宜2.99$ 500G的流量
```

```
我个人使用的是
digitalocean的 DEBIAN 7 x64位 此版本搭建SSR/锐速/bbr基本没有遇到故障。
Centos应该也是可以得
```
![debain7](http://owrmua5nw.bkt.clouddn.com/debain7.png)
* * *

* 机房推荐 Japan , New York , Los Angeles 其他的可以自行测速。
![选择机房](http://owrmua5nw.bkt.clouddn.com/%E9%80%89%E6%8B%A9%E6%9C%BA%E6%88%BF.png)

```
获得vps后会给你账号密码通过邮箱的方式。

首先我们先ping 一下ip地址。看是否ping的通。ping多几次
如果一直显示连接超时，那么就把原来的vps删除，重新创建一个。在ping ，直到ping的通为止。

之后我们下载Xshell  
http://rj.baidu.com/soft/detail/15201.html?ald
用ssh连接

打开xshell 文件 -> 新建 填写ip后点击确认 之后根据提示操作。
```
![vpsip](http://owrmua5nw.bkt.clouddn.com/vpsip.png)

## 安装SSR
```
登陆成功后 按顺序执行三条命令
wget --no-check-certificate	 https://raw.githubusercontent.com/teddysun/shadowsocks_install/master/shadowsocksR.sh

chmod +x shadowsocksR.sh

./shadowsocksR.sh 2>&1 | tee shadowsocksR.log
```
![ssr3](http://owrmua5nw.bkt.clouddn.com/ssr%203.png)

之后会让你设置端口，密码，混淆协议，以及端口加密方式等。
安装完成后的图要保存一下。
![ssr](http://owrmua5nw.bkt.clouddn.com/ssr.png)

本脚本安装完成后，已将ShadowsocksR加入开机启动


## 锐速优化

![ruijie加速](http://owrmua5nw.bkt.clouddn.com/ssr%E5%8A%A0%E9%80%9F.png)
锐速用于给服务器加速，嫌麻烦的可以不装

锐速破解版安装脚本，来自91云

PS：锐速不支持openvz的服务器，如果你购买的是搬瓦工，一定要注意选择kvm而不是openvz

```
脚本一：

wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder.sh && bash serverspeeder.sh
```

```
备用脚本：

wget -N --no-check-certificate https://raw.githubusercontent.com/91yun/serverspeeder/master/serverspeeder-all.sh && bash serverspeeder-all.sh

```
![ruijie](http://owrmua5nw.bkt.clouddn.com/ruijie.png)

安装完毕后就大功告成了，找到对应的客户端版本并安装，然后按照上面记下来的配置信息连接到你的SSR服务器就好了！
youtube 1080p 美滋滋
```
ShadowsocksR Windows版下载

链接：http://pan.baidu.com/s/1eSeXCcy 密码：wb0h

ShadowsocksR Android版下载

链接：http://pan.baidu.com/s/1jH5DCs2 密码：jb6h

ShadowsocksR Mac版下载

链接：http://pan.baidu.com/s/1c2LFcSK 密码：rn8n

```