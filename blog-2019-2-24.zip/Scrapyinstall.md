---
title: Python3 Scrapy Install
date: 2017-10-19 20:14:50
categories:
	- Scrapy 
tags:
	- Scrapy Install
---

人生苦短，我用Python.<!-- more -->

# windows下的安装
```
前言：一般我们安装Python包，都是使用python自带的包管理pip进行安装
这时我们使用pip来安装下Scrapy
```
![installscrapy](http://owrmua5nw.bkt.clouddn.com/installscrapy.png)

* 可以看到前面我们很顺利，接下来。

![errorscrapy](http://owrmua5nw.bkt.clouddn.com/errorscrapy.png)

```
解决：
先安装wheel包 这里因为我的系统只有python3  如果你python2，3都有的话最好指定pip3安装。
```
![wheel](http://owrmua5nw.bkt.clouddn.com/wheel.png)

之后去这个[网站](http://www.lfd.uci.edu/~gohlke/pythonlibs/#lxml)找包,里边是编译好的各种库。找到后下载安装。
上面错误提示我们创建一个twisted

![wheelinstall](http://owrmua5nw.bkt.clouddn.com/wheelinstall.png)

在安装Scrapy

![wheelscrapy](http://owrmua5nw.bkt.clouddn.com/wheelscrapy.png)
    
成功之后我们在cmd输入scrapy

![scrapy](http://owrmua5nw.bkt.clouddn.com/scrapy.png)

之后还要安装一个pillow,否则会报错PIL no module
在使用scrapy框架下载图片的使用会用到PIL这个包，这是python2的 python3用pillow的替代了。

![pillow](http://owrmua5nw.bkt.clouddn.com/pillow.png)

第一次跑scrapy 会报错
原因是缺少win32

![win32api](http://owrmua5nw.bkt.clouddn.com/win32api.png)

解决方法去

https://sourceforge.net/projects/pywin32/files/

找对应的版本下载，安装即可,下错版本也不要紧，安装不了的。

![installwin32](http://owrmua5nw.bkt.clouddn.com/installwin32.png)

```
Python最好还是在ubuntu下跑，windows不知道什么原因，ubuntu能跑，windows经常回显一片空白。
```

# ubuntu下的安装

1.
```
sudo apt-get install python-dev python-pip libxml2-dev libxslt1-dev zlib1g-dev libffi-dev libssl-dev
```

2.
```
sudo apt-get install python3 python3-dev
```

3.
```
pip3 install scrapy
```