---
title: Nmap
date: 2017-11-18 09:27:35
categories:
	- tools
tags:
	- tools
---

Nmap是一个用于网络探索和安全审计的开源工具。<!-- more -->

# Nmap扫描的4种基本技术
```
Network Mapping    网络映射

Port Scanning     端口扫描

Service and Version Detection   服务与版本信息探测

OS Detection  操作系统探测

传输层管理逻辑地址（ports），ports类似于一栋大楼的房间号。决定了数据的具体去向

传输层在两个machines间建立连接
会话层在两个process间建立连接


port决定了incoming的数据属于哪个运用程序
```

* 几个debug相关参数
```
-v 

-d

-p 

可重复，例如namp -sV -n --reason -v -v 127.0.0.1
```

## Host Discovery 
```
任何网络侦察任务的开始都是将一系列IP范围缩小到一个活跃或感兴趣的主机列表中

这里要说明一下，
当使用nmap探测的目标是同一网段时，
无论是探测端口，操作系统，服务，主机，
nmap首选都是发送arp请求的，因为在同网段中它几乎总是更快，更有效，
除非 --disable-arp-ping或--send-ip指定

在下图中我们没有给出扫描的参数
那么Nmap默认会发送
一个ICMP回应请求，
一个TCP SYN数据包到端口443，
一个TCP ACK数据包到端口80
和一个ICMP时间戳请求。
这些默认值等同于-PE -PS443 -PA80 -PP选项。

-n 不要做反向dns解析，缩短扫描时间。
```
![nmaparp](http://owrmua5nw.bkt.clouddn.com/nmaparp.png)

![nmaparp2](http://owrmua5nw.bkt.clouddn.com/nmaparp2.png)

### 主机发现技术类型

* 指定目的主机的三种方式
![host](http://owrmua5nw.bkt.clouddn.com/host.png)

![host1](http://owrmua5nw.bkt.clouddn.com/host1.png)

* ICMP ECHO Request
```
ping扫描
```

* ICMP Timestamp
```
ICMP 时间戳请求，如果目标存在，将返回当前时间
```

* ICMP Address Mask Request
```
icmp请求地址掩码，如果目标存在，将返回它的子网掩码
```

* TCP ping
```
发送一个TCP SYN or TCP ACK包去探测目的ip，还还需要提供指定的端口数量，例如 21，25，or 80.

响应的结果，决定于发送的包，目的OS，防火墙或者ACL
```

* UDP ping
```
发送一个UDP数据包和一个指定的UDP端口去探测目标地址。
如果目标地址是存在的，但是port是关闭的，那么目标系统
会发送回来一个icmp 端口不可达，然而由于udp的无连接性质，
UDP扫描没有回应，也有可能端口是打开的
```

### Nmap主机发现的一些参数
```
-sn （禁止端口扫描） 

ping扫描，但比ping广播地址更可靠，因为许多主机不回复广播查询。该选项告诉Nmap不要在主机发现后执行端口扫描

-Pn (不能ping 跳过主机发现)

当我们明确的知道了主机的存活，可以使用-Pn,跳过主机发现，减少扫描时间，

-PU <port list> （UDP Ping）
如果没有指定端口，则默认为40125


--traceroute （跟踪主机的路径）
Nmap的跟踪路由以高TTL开始，然后递减TTL直到达到零。
可以用来初步判断一下cnd的真实ip，看最后一跳的地址。


```

```
-PS <port list> （TCP SYN Ping）syn扫描
默认的目标端口是80

```
![syn](http://owrmua5nw.bkt.clouddn.com/syn.png)

```
-PA <port list> (TCP ACK Ping)tcp扫描
默认的目标端口是80
```
![tcp](http://owrmua5nw.bkt.clouddn.com/tcp.png)

```
tcp 与syn扫描的区别：
tcp是建立连接的扫描。会被目标主机记录log日志，
而syn扫描没有建立连接，不易被主机log，但是容易被IPS发现

-PS和-PA的配合能够发现状态和非状态防火墙。
```

## Port and Service Scanning

端口扫描技术

* Connect scan
```
建立tcp连接的扫描，原理跟上面的tcp连接图相似

```

* Half-open scan
```
半开式扫描，即syn扫描
```

* stealth scan
```
使用不同的flag设置不同的stealth scan
例如：FIN，NULL和Xmas扫描
```

### Nmap的6种端口状态
* open - 打开 
* closed - 关闭
* filtered - 回应被过滤
* Unfiltered - ack scan,open and closed 回应都是RST
* open|filtered 开放的UDP端口不回应，或者回应的icmp被过滤。(UDP,IP PROTO,FIN,NULL,Xmas scans)
* closed|filtered （ip idle scan only 利用ID 位进行扫描）
![id](http://owrmua5nw.bkt.clouddn.com/id.png)


### idle scan 最终的隐形扫描
根据id的大小来判断端口的开放情况，
[idle scan参考文档](https://nmap.org/book/idlescan.html)
![openid](http://owrmua5nw.bkt.clouddn.com/openid.png)

![idclosed](http://owrmua5nw.bkt.clouddn.com/idclosed.png)

![idfilter](http://owrmua5nw.bkt.clouddn.com/idfilter.png)

### Nmap端口扫描的一些参数
```

-p <port ranges> （只扫描指定的端口）
可以通过T:TCP 端口号，U:UDP 端口号， S:SCTP 端口号或P:IP协议端口号来指定特定的协议

nmap -p -100 192.168.1.1 扫描 1到100端口
nmap -p 100- 192.168.1.1 扫描100到65535
nmap -p- 192.168.1.1   扫描所有端口

-sS （TCP SYN扫描）半开扫描

nmap发送一个SYN数据包，然后等待响应。
SYN / ACK指示端口正在侦听（打开），
而RST（重置）指示 非侦听器。
如果在多次重传后没有收到响应，端口将被标记为已过滤。
如果接收到ICMP不可达错误（类型3，代码0,1,2,3,9,10或13），则该端口也被标记为过滤

-sT （TCP连接扫描）
会在目标主机log日志出现一连串的连接尝试

-sU （UDP扫描）

一个服务会以一个UDP数据包作为回应，证明它是open。
如果重传后没有收到回应，则该端口被分类为open|filtered。
这意味着端口可能是开放的，或者数据包过滤器阻塞了通信。
版本检测（-sV）可以用来帮助区分真正开放的端口和过滤的端口。

-sA （TCP ACK扫描）
它用于绘制防火墙规则集，确定它们是否是有状态的以及哪些端口被过滤。

当扫描未经过滤系统， open以及closed端口都将返回一个RST包。Nmap中作为 unfiltered，
这意味着它们可以连ACK包，但端口是open还是closed不确定。

没有响应的端口或发送特定的ICMP错误消息被标记filtered。
```
![sa](http://owrmua5nw.bkt.clouddn.com/sa.png)

![tcpudp](http://owrmua5nw.bkt.clouddn.com/tcpudp.png)


## Service and Version Detection 
服务和版本检测

```
-sV （版本检测）

--version-intensity <intensity> （设置版本扫描强度)

数字越高，服务被正确识别的可能性就越大。
但是，高强度扫描需要更长的时间。
强度必须在0到9之间。 默认值是7

--version-all （尝试每一个探针）
```
```
C:\Users\lxhsec>nmap -n  -v -sS 192.168.1.1
```
![sv](http://owrmua5nw.bkt.clouddn.com/sv.png)

```
C:\Users\lxhsec>nmap -n  -v -sS -sV 192.168.1.1
当识别不出的时候可以尝试加大探针强度。
```
![sv1](http://owrmua5nw.bkt.clouddn.com/sv1.png)


## OS Detection  
操作系统探测
```
-O （启用操作系统检测）

--osscan-guess; --fuzzy（当检测不出准确的操作系统时，可以用这个参数让nmap猜测操作系统）
```

```
-A 可以检测操作系统，版本服务，脚本检测，默认端口扫描，路由追踪
```

## Nmap Scripting Engine (NSE)
```
Nmap脚本引擎（NSE）是Nmap最强大，最灵活的功能之一
Lua编程语言编写namp插件

-sC
使用默认的一组脚本执行脚本扫描。

--script <filename> 指定脚本

--script-help <filename>

显示有关脚本的帮助。
对于与给定规范相匹配的每个脚本，
Nmap都会打印脚本名称，类别和描述

--script-args <n1>=<v1>,<n2>={<n3>=<v3>}

为NSE脚本提供参数
```
![script](http://owrmua5nw.bkt.clouddn.com/script.png)
[列出了每个脚本接受的参数](https://nmap.org/nsedoc/)

[Firewall/IDS Evasion and Spoofing](https://nmap.org/book/man-bypass-firewalls-ids.html)

![source](http://owrmua5nw.bkt.clouddn.com/source.png)

![fenpian](http://owrmua5nw.bkt.clouddn.com/fenpian.png)

```
当然nmap还有许许多多的参数，这里我只是简单的介绍了一些。
个人理解，仅供参考。
```