---
title: Hexo
date: 2017-9-24 20:30:44
---


Hexo是一个快速、简洁且高效的博客框架<!-- more -->，
而Git是目前世界上最先进的分布式版本控制系统，
利用Github Page可以免费创建一个静态网站。
下面将介绍如何使用Hexo和Github，在win10环境下搭建一个静态的博客。

# 安装和配置Hexo及Github

## 安装Hexo

安装Hexo前需要安装一下：

*   [node.js](https://nodejs.org/en/)
*   [Git](https://git-scm.com/download/win)
*   由于Git下载过慢，提供[限速云](http://pan.baidu.com/s/1c1421UC)下载。pqvt

如果已经安装完成以上程序，打开Git-bash或者cmd，输入

`npm config set registry http://registry.npm.taobao.org/`

将node.js的npm源换成淘宝源,不然下载不下来。

* * *

接着输入
`npm install -g hexo-cli`

即可完成Hexo的安装。

## 使用Hexo进行本地建站

输入
```
hexo init D:\hexo
cd D:\hexo
npm install
```
如果hexo安装成功，则在D:\hexo文件夹下的文件目录为

![tupian](http://owrmua5nw.bkt.clouddn.com/1.png)

详细文件或文件夹的具体含义见 [Hexo官方文档之建站](https://hexo.io/zh-cn/docs/setup.html)

测试本地建站是否成功，输入 

`hexo s --debug`

如显示

![tupian](http://owrmua5nw.bkt.clouddn.com/2.png)

则说明本地建站成功，访问[本地地址](http://localhost:4000/)可以看到Hexo默认主题的效果。

至此,Hexo安装以及本地搭建完成。

## 创建Github账号

下面假设你创建的账户名为lyxhh

## 创建与账号同名的Repository

登陆成功后点击如图，按照图填写 你的Github账号名.github.io，完成创建

![tupian](http://owrmua5nw.bkt.clouddn.com/3.png)
![tupian](http://owrmua5nw.bkt.clouddn.com/4.png)

## 配置SSH

(1)生成ssh

检查是否已经有SSH Key， 打开Git Bash 输入

`cd ~/.ssh`

如果没有这个目录，则生成一个新的SSH，输入

`ssh-keygen -t rsa -C "your e-mail"`

其中，your e-mail是你注册Github时用到的邮箱。

然后接下来几步都直接按回车键，最后生成如下

![tupian](http://owrmua5nw.bkt.clouddn.com/5.png)

(2) 复制公钥内容到Github账户信息中

![tupian](http://owrmua5nw.bkt.clouddn.com/6.png)

登陆Github，点击头像，看图

![tupian](http://owrmua5nw.bkt.clouddn.com/7.png)
![sshkey](http://owrmua5nw.bkt.clouddn.com/sshkey.png)

(3)测试SSH是否配置成功

输入

`ssh -T git@github.com`

如果显示以下，则说明ssh配置成功。

![tupian](http://owrmua5nw.bkt.clouddn.com/ssh.png)

## 将hexo发布在github 上

![tupian](http://owrmua5nw.bkt.clouddn.com/9.png)

进去你创建的仓库把克隆的地址复制下来(例如 “[https://github.com/lyxhh/lyxhh.github.io.git](https://github.com/lyxhh/lyxhh.github.io.git) “)

打开本地的hexo（D:\hexo ），修改其中的“_config.yml”文件。在最后加入一下内容（repository 后就是我们克隆仓库的 https）

![tupian](http://owrmua5nw.bkt.clouddn.com/10.png)

将修改后的所有文件 推送到远端.然后本地repository(即D:\hexo) 中右键打开git bash here 执行

```
hexo clean
hexo generate
hexo deploy
```

执行hexo deploy 时会让输入github 的账号密码。

## 报错

执行hexo deploy 时可能会报错ERROR Deployer not found: git 或者 ERROR Deployer not found: github

解决方法： `npm install hexo-deployer-git –save`
* 注意：要在hexo目录下执行

```
之后执行deploy 会让你运行下面这两条命令，
  git config --global user.email "you@example.com"
  git config --global user.name "Your Name"

```

然后再把本地有变化的文件提交到远端 重新执行

```
hexo clean  清除缓存
hexo generate	生成文件
hexo deploy	 部署到github中
```

此时就已经ok了，等待hexo deploy执行完毕，就可以在浏览器输入“[https://lyxhh.github.io/”](https://lyxhh.github.io/”) 进行访问我们的hexo博客了。 

之后你看到的hexo是默认主题

本博客采用next主题，具体安装设置请参考[官方文档](http://theme-next.iissnan.com/)。

